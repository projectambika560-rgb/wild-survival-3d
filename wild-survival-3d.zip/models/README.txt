Put .obj + .mtl files here (optional)
