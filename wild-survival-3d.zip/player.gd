extends CharacterBody3D

const WALK := 4.2
const RUN := 7.2
const JUMP := 6.8
const GRAV := 22.0

var main
var yaw := 0.0
var pitch := -0.3
var move_input := Vector2.ZERO
var run_on := false
var want_jump := false
var face := Vector3(0, 0, 1)
var model: Node3D
var arm_r: Node3D
var arm_l: Node3D
var leg_r: Node3D
var leg_l: Node3D
var held: Node3D
var pivot: Node3D
var spring: SpringArm3D
var cam: Camera3D
var moving := false
var sprinting := false
var anim := 0.0
var swing_t := 0.0
var cam_dist := 5.5


func box(parent: Node, size: Vector3, pos: Vector3, col: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	m.mesh = b
	var mt := StandardMaterial3D.new()
	mt.albedo_color = col
	mt.roughness = 1.0
	m.material_override = mt
	m.position = pos
	parent.add_child(m)
	return m


func part(parent: Node, mesh: Mesh, pos: Vector3, col: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	var mt := StandardMaterial3D.new()
	mt.albedo_color = col
	mt.roughness = 0.9
	m.material_override = mt
	m.position = pos
	parent.add_child(m)
	return m


func capsule(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = maxf(h, r * 2.0 + 0.01)
	c.radial_segments = 10
	c.rings = 4
	return c


func sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 10
	s.rings = 5
	return s


func limb(pos: Vector3, r: float, length: float, col: Color, tip: Color) -> Node3D:
	var pv := Node3D.new()
	pv.position = pos
	model.add_child(pv)
	part(pv, capsule(r, length), Vector3(0, -length * 0.5, 0), col)
	part(pv, sphere(r * 0.95), Vector3(0, -length + r * 0.6, 0.0), tip)
	return pv


func setup(m) -> void:
	main = m
	collision_layer = 2
	collision_mask = 5
	floor_snap_length = 0.5
	floor_max_angle = deg_to_rad(50.0)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	cs.shape = cap
	cs.position.y = 0.85
	add_child(cs)

	model = Node3D.new()
	add_child(model)
	var torso := part(model, capsule(0.25, 0.8), Vector3(0, 1.15, 0), Color(0.22, 0.38, 0.22))
	torso.scale = Vector3(1.15, 1.0, 0.78)
	part(model, sphere(0.16), Vector3(0, 1.68, 0), Color(0.85, 0.68, 0.52))
	var hair := part(model, sphere(0.17), Vector3(0, 1.74, -0.02), Color(0.25, 0.16, 0.1))
	hair.scale = Vector3(1.0, 0.7, 1.05)
	box(model, Vector3(0.42, 0.5, 0.22), Vector3(0, 1.2, -0.27), Color(0.5, 0.3, 0.14))
	var rc := CylinderMesh.new()
	rc.top_radius = 0.09
	rc.bottom_radius = 0.09
	rc.height = 0.5
	var roll := part(model, rc, Vector3(0, 1.5, -0.27), Color(0.35, 0.4, 0.3))
	roll.rotation_degrees.z = 90.0
	leg_l = limb(Vector3(-0.13, 0.85, 0), 0.1, 0.85, Color(0.2, 0.22, 0.3), Color(0.1, 0.08, 0.07))
	leg_r = limb(Vector3(0.13, 0.85, 0), 0.1, 0.85, Color(0.2, 0.22, 0.3), Color(0.1, 0.08, 0.07))
	arm_l = limb(Vector3(-0.38, 1.45, 0), 0.075, 0.62, Color(0.22, 0.38, 0.22), Color(0.85, 0.68, 0.52))
	arm_r = limb(Vector3(0.38, 1.45, 0), 0.075, 0.62, Color(0.22, 0.38, 0.22), Color(0.85, 0.68, 0.52))
	held = Node3D.new()
	arm_r.add_child(held)
	box(held, Vector3(0.06, 0.9, 0.06), Vector3(0, -0.5, 0.2), Color(0.45, 0.3, 0.15))
	box(held, Vector3(0.22, 0.14, 0.08), Vector3(0, -0.95, 0.2), Color(0.6, 0.6, 0.62))
	held.visible = false

	pivot = Node3D.new()
	pivot.position = Vector3(0, 1.5, 0)
	add_child(pivot)
	spring = SpringArm3D.new()
	spring.spring_length = cam_dist
	spring.margin = 0.4
	spring.collision_mask = 1
	spring.add_excluded_object(get_rid())
	pivot.add_child(spring)
	cam = Camera3D.new()
	cam.fov = 70.0
	cam.far = 240.0
	spring.add_child(cam)


func look(rel: Vector2) -> void:
	yaw -= rel.x * 0.006
	pitch = clampf(pitch - rel.y * 0.005, -1.25, 0.15)


func swing() -> void:
	swing_t = 0.3


func key_vec() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_W):
		v.y -= 1.0
	if Input.is_physical_key_pressed(KEY_S):
		v.y += 1.0
	if Input.is_physical_key_pressed(KEY_A):
		v.x -= 1.0
	if Input.is_physical_key_pressed(KEY_D):
		v.x += 1.0
	return v


func _physics_process(delta: float) -> void:
	if main == null or main.state != "play":
		return
	var mi := move_input + key_vec()
	if mi.length() > 1.0:
		mi = mi.normalized()
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	var dir := right * mi.x + fwd * (-mi.y)
	moving = dir.length() > 0.1
	var want_run: bool = run_on or Input.is_physical_key_pressed(KEY_SHIFT)
	sprinting = want_run and moving and main.stats["stamina"] > 4.0
	var spd := RUN if sprinting else WALK
	if moving:
		spd *= clampf(mi.length(), 0.45, 1.0)
	velocity.x = move_toward(velocity.x, dir.x * spd, 45.0 * delta)
	velocity.z = move_toward(velocity.z, dir.z * spd, 45.0 * delta)
	if is_on_floor():
		if want_jump and main.stats["stamina"] > 8.0:
			velocity.y = JUMP
			main.stats["stamina"] -= 8.0
		else:
			velocity.y = 0.0
	else:
		velocity.y -= GRAV * delta
	want_jump = false
	move_and_slide()
	if moving:
		var ang := atan2(dir.x, dir.z)
		model.rotation.y = lerp_angle(model.rotation.y, ang, minf(1.0, 14.0 * delta))
		face = Vector3(sin(model.rotation.y), 0.0, cos(model.rotation.y))


func _process(delta: float) -> void:
	if pivot == null:
		return
	if Input.is_physical_key_pressed(KEY_LEFT):
		yaw += 1.8 * delta
	if Input.is_physical_key_pressed(KEY_RIGHT):
		yaw -= 1.8 * delta
	if Input.is_physical_key_pressed(KEY_UP):
		pitch = clampf(pitch - 1.0 * delta, -1.25, 0.15)
	if Input.is_physical_key_pressed(KEY_DOWN):
		pitch = clampf(pitch + 1.0 * delta, -1.25, 0.15)
	pivot.rotation.y = yaw
	spring.rotation.x = pitch
	if main == null or main.state != "play":
		return
	held.visible = main.inv.has("axe") or main.inv.has("spear")
	var hv := Vector2(velocity.x, velocity.z).length()
	if not is_on_floor():
		arm_l.rotation.x = lerpf(arm_l.rotation.x, -2.2, 10.0 * delta)
		arm_r.rotation.x = lerpf(arm_r.rotation.x, -2.2, 10.0 * delta)
		leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.5, 10.0 * delta)
		leg_r.rotation.x = lerpf(leg_r.rotation.x, -0.4, 10.0 * delta)
	elif hv > 0.5:
		anim += delta * hv * 1.9
		var s := sin(anim) * 0.9
		leg_l.rotation.x = s
		leg_r.rotation.x = -s
		arm_l.rotation.x = -s * 0.8
		arm_r.rotation.x = s * 0.8
	else:
		leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.0, 10.0 * delta)
		leg_r.rotation.x = lerpf(leg_r.rotation.x, 0.0, 10.0 * delta)
		arm_l.rotation.x = lerpf(arm_l.rotation.x, 0.0, 10.0 * delta)
		arm_r.rotation.x = lerpf(arm_r.rotation.x, 0.0, 10.0 * delta)
		model.scale.y = 1.0 + sin(Time.get_ticks_msec() * 0.003) * 0.012
	if swing_t > 0.0:
		swing_t -= delta
		arm_r.rotation.x = -sin((1.0 - maxf(swing_t, 0.0) / 0.3) * PI) * 2.4
