extends Node3D

const PlayerScript = preload("res://player.gd")
const AnimalScript = preload("res://animal.gd")
const HudScript = preload("res://hud.gd")

const ISLAND_R := 70.0
const GRID := 72
const CELL := 2.2
const WORLD_SEED := 20260
const SAVE_PATH := "user://save.json"
const SETTINGS_PATH := "user://settings.json"
const DAY_LENGTH := 240.0

# Optional AI backend URL (Cloudflare Worker). Leave "" = game is 100% offline.
var ai_endpoint := ""

var MAX_ITEMS := 40
var ITEMS := {
	"wood": ["Wood", "Used for tools, campfire and shelter."],
	"stone": ["Stone", "Used for tools and fire rings."],
	"berries": ["Berries", "Eat: +8 food, +4 water."],
	"raw_meat": ["Raw Meat", "Cook it at a campfire. Eating raw is risky."],
	"cooked_meat": ["Cooked Meat", "Eat: +35 food, +5 health."],
	"axe": ["Stone Axe", "Tool. Gives double wood per chop (automatic)."],
	"spear": ["Spear", "Tool. Strong weapon for hunting (automatic)."],
}
var RECIPES := {
	"axe": {"name": "Stone Axe", "desc": "Chop 2x wood per hit", "cost": {"wood": 3, "stone": 2}},
	"spear": {"name": "Spear", "desc": "Strong hunting weapon", "cost": {"wood": 4, "stone": 1}},
	"campfire": {"name": "Campfire", "desc": "Light, warmth, cooking", "cost": {"wood": 5, "stone": 3}},
	"shelter": {"name": "Wooden Shelter", "desc": "Sleep safely at night", "cost": {"wood": 12, "stone": 2}},
	"box": {"name": "Storage Box", "desc": "Store items safely", "cost": {"wood": 6}},
}
var MISSIONS := [
	{"t": "Collect 5 wood (INTERACT near trees)", "k": "wood", "n": 5, "xp": 20},
	{"t": "Collect 3 stone (INTERACT near rocks)", "k": "stone", "n": 3, "xp": 20},
	{"t": "Craft and place a Campfire (MAKE button)", "k": "fire", "n": 1, "xp": 40},
	{"t": "Build a Wooden Shelter", "k": "shelter", "n": 1, "xp": 60},
	{"t": "Hunt an animal (HIT button)", "k": "kills", "n": 1, "xp": 50},
	{"t": "Eat food 3 times (BAG > USE)", "k": "food", "n": 3, "xp": 30},
	{"t": "Find the Ancient Ruins on the high ground", "k": "ruins", "n": 1, "xp": 80},
	{"t": "Survive until Day 4", "k": "day", "n": 4, "xp": 200},
]
var GUIDE := {
	"Intro": "Welcome! Tap a topic below, or ASK GUIDE for a tip based on your situation.",
	"Crafting": "Open MAKE (or BAG > Crafting).\nStone Axe: 3 wood + 2 stone.\nSpear: 4 wood + 1 stone.\nCampfire: 5 wood + 3 stone (cook, warmth, scares wolves).\nShelter: 12 wood + 2 stone (sleep at night).\nStorage Box: 6 wood.",
	"Resources": "Walk near trees, rocks or red bushes and tap INTERACT to collect wood, stone and berries. Stand at the shore and tap INTERACT to drink. Animals drop raw meat; cook it at a campfire.",
	"Missions": "Follow the mission text at the top-left. Missions give XP and levels. Find the old hermit's camp and the Ancient Ruins on the high ground. Tap NEW BONUS MISSION for extra goals.",
	"Survival": "Keep FOOD and WATER above zero or you lose health. Running uses stamina. Wolves hunt you; stay near a campfire. Sleep in a shelter at night to skip the dark.",
}

var noise: FastNoiseLite
var hgrid := PackedFloat32Array()
var player
var hud
var sun: DirectionalLight3D
var moon: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var menu_cam: Camera3D
var rain: CPUParticles3D
var sea: MeshInstance3D
var sea_mat: StandardMaterial3D
var grass_node: MultiMeshInstance3D
var tree_mm: MultiMesh
var tree_mesh: ArrayMesh
var model_trees: Array = []
var model_rocks: Array = []
var model_bushes: Array = []
var model_animals := {}
var rain_audio: AudioStreamPlayer
var wind_audio: AudioStreamPlayer
var music_audio: AudioStreamPlayer
var sfx_pool: Array = []
var sfx_streams := {}
var sfx_i := 0
var mats := {}
var rng := RandomNumberGenerator.new()
var map_tex: ImageTexture
var spawn_pos := Vector3.ZERO
var ruins_pos := Vector3.ZERO
var camp_pos := Vector3.ZERO

var state := "loading"
var settings := {"quality": 1, "volume": 0.8, "ai": false}
var time_of_day := 0.30
var day := 1
var raining := false
var rain_f := 0.0
var rain_timer := 50.0
var stats := {"hp": 100.0, "stamina": 100.0, "hunger": 100.0, "thirst": 100.0}
var inv := {}
var box_store := {}
var xp := 0
var level := 1
var mission_idx := 0
var counters := {"wood": 0, "stone": 0, "fire": 0, "shelter": 0, "kills": 0, "food": 0, "ruins": 0}
var achievements := {}
var bonus := {}
var structures: Array = []
var menu_angle := 0.0
var tick := 0.0
var autosave_t := 0.0
var step_t := 0.0
var t_total := 0.0
var world_dirty := false
var amb_t := 10.0
var thunder_t := 20.0
var flash_t := 0.0
var player_safe := false


# =================================================================== startup
func _ready() -> void:
	randomize()
	load_settings()
	hud = HudScript.new()
	add_child(hud)
	hud.setup(self)
	hud.show_panel("loading")
	hud.set_loading("Preparing...")
	await get_tree().process_frame
	await get_tree().process_frame
	build_environment()
	build_audio()
	hud.set_loading("Shaping the island...")
	await get_tree().process_frame
	build_noise()
	build_terrain()
	build_sea()
	build_map_texture()
	hud.set_loading("Planting the forest...")
	await get_tree().process_frame
	player = PlayerScript.new()
	add_child(player)
	player.setup(self)
	spawn_pos = find_spawn()
	player.position = spawn_pos + Vector3(0, 1.5, 0)
	scan_models()
	populate_world()
	apply_quality(int(settings["quality"]))
	set_volume(float(settings["volume"]))
	update_sky()
	state = "menu"
	hud.show_panel("menu")


func world_size() -> float:
	return GRID * CELL


func build_environment() -> void:
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sun_angle_min = 0.5
	sky_mat.sun_angle_max = 30.0
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.65, 0.7)
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_density = 0.0028
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 0.92
	env.fog_sky_affect = 0.3
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, 30, 0)
	sun.shadow_enabled = true
	add_child(sun)
	moon = DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-55, -40, 0)
	moon.light_color = Color(0.5, 0.6, 1.0)
	moon.light_energy = 0.0
	add_child(moon)
	menu_cam = Camera3D.new()
	menu_cam.far = 400.0
	add_child(menu_cam)
	menu_cam.make_current()
	rain = CPUParticles3D.new()
	rain.amount = 280
	rain.lifetime = 0.9
	rain.emitting = false
	rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain.emission_box_extents = Vector3(14, 0.5, 14)
	rain.direction = Vector3(0.1, -1, 0)
	rain.spread = 2.0
	rain.gravity = Vector3(0, -10, 0)
	rain.initial_velocity_min = 18.0
	rain.initial_velocity_max = 22.0
	var rm := BoxMesh.new()
	rm.size = Vector3(0.02, 0.6, 0.02)
	var rmat := StandardMaterial3D.new()
	rmat.albedo_color = Color(0.75, 0.85, 1.0, 0.5)
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.material = rmat
	rain.mesh = rm
	add_child(rain)


func build_noise() -> void:
	noise = FastNoiseLite.new()
	noise.seed = WORLD_SEED
	noise.frequency = 0.025
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.fractal_octaves = 3


# =================================================================== terrain
func raw_height(x: float, z: float) -> float:
	var d := Vector2(x, z).length() / ISLAND_R
	var fall := clampf(1.0 - d * d, -1.0, 1.0)
	var n := noise.get_noise_2d(x, z)
	var h := fall * 9.0 + n * 6.0 * clampf(fall + 0.3, 0.0, 1.0) - 1.5
	var m := Vector2(x - 20.0, z + 18.0).length()
	h += maxf(0.0, 1.0 - m / 22.0) * 14.0
	return h


func height_at(x: float, z: float) -> float:
	var half := GRID * CELL * 0.5
	var fx := (x + half) / CELL
	var fz := (z + half) / CELL
	var ix := clampi(int(floor(fx)), 0, GRID - 1)
	var iz := clampi(int(floor(fz)), 0, GRID - 1)
	var tx := clampf(fx - ix, 0.0, 1.0)
	var tz := clampf(fz - iz, 0.0, 1.0)
	var w := GRID + 1
	var h00 := hgrid[ix * w + iz]
	var h10 := hgrid[(ix + 1) * w + iz]
	var h01 := hgrid[ix * w + iz + 1]
	var h11 := hgrid[(ix + 1) * w + iz + 1]
	if tx + tz <= 1.0:
		return h00 + (h10 - h00) * tx + (h01 - h00) * tz
	return h11 + (h01 - h11) * (1.0 - tx) + (h10 - h11) * (1.0 - tz)


func ground_color(h: float, slope: float, x: float, z: float) -> Color:
	var p := 0.5 + 0.5 * noise.get_noise_2d(x * 4.0, z * 4.0)
	var grass := Color(0.30, 0.40, 0.14).lerp(Color(0.13, 0.30, 0.10), p)
	var sand := Color(0.80, 0.72, 0.52).lerp(Color(0.62, 0.55, 0.40), clampf(1.0 - h, 0.0, 1.0))
	var rock := Color(0.46, 0.43, 0.39).lerp(Color(0.34, 0.32, 0.30), p)
	var c := sand.lerp(grass, smoothstep(0.7, 1.7, h))
	c = c.lerp(rock, maxf(smoothstep(0.16, 0.3, slope), smoothstep(9.5, 12.0, h)))
	c = c.lerp(Color(0.74, 0.76, 0.79), smoothstep(18.0, 21.0, h))
	if h < 0.0:
		c = Color(0.55, 0.5, 0.38)
	return c


func add_tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, ca: Color, cb: Color, cc: Color) -> void:
	st.set_smooth_group(0)
	st.set_color(ca)
	st.add_vertex(a)
	st.set_color(cb)
	st.add_vertex(b)
	st.set_color(cc)
	st.add_vertex(c)


func make_detail_tex() -> ImageTexture:
	var n := FastNoiseLite.new()
	n.seed = 7
	n.frequency = 0.06
	n.fractal_octaves = 4
	var src := n.get_seamless_image(128, 128)
	var img := Image.create(128, 128, true, Image.FORMAT_RGB8)
	for x in 128:
		for y in 128:
			var v := src.get_pixel(x, y).r
			var b := 0.65 + 0.35 * v
			img.set_pixel(x, y, Color(b, b, b))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func make_wave_normal() -> ImageTexture:
	var n := FastNoiseLite.new()
	n.seed = 11
	n.frequency = 0.05
	n.fractal_octaves = 3
	var sz := 128
	var hm := n.get_seamless_image(sz, sz)
	var img := Image.create(sz, sz, true, Image.FORMAT_RGB8)
	for x in sz:
		for y in sz:
			var hl := hm.get_pixel((x - 1 + sz) % sz, y).r
			var hr := hm.get_pixel((x + 1) % sz, y).r
			var hu := hm.get_pixel(x, (y - 1 + sz) % sz).r
			var hd := hm.get_pixel(x, (y + 1) % sz).r
			var nv := Vector3((hl - hr) * 3.0, (hu - hd) * 3.0, 1.0).normalized()
			img.set_pixel(x, y, Color(nv.x * 0.5 + 0.5, nv.y * 0.5 + 0.5, nv.z * 0.5 + 0.5))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func build_terrain() -> void:
	var half := GRID * CELL * 0.5
	var w := GRID + 1
	hgrid.resize(w * w)
	for i in w:
		for j in w:
			hgrid[i * w + j] = raw_height(i * CELL - half, j * CELL - half)
	var cols: Array = []
	cols.resize(w * w)
	for i in w:
		for j in w:
			var hl := hgrid[maxi(i - 1, 0) * w + j]
			var hr := hgrid[mini(i + 1, GRID) * w + j]
			var hd := hgrid[i * w + maxi(j - 1, 0)]
			var hu := hgrid[i * w + mini(j + 1, GRID)]
			var gx := (hr - hl) / (2.0 * CELL)
			var gz := (hu - hd) / (2.0 * CELL)
			var slope := 1.0 - 1.0 / sqrt(1.0 + gx * gx + gz * gz)
			cols[i * w + j] = ground_color(hgrid[i * w + j], slope, i * CELL - half, j * CELL - half)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in GRID:
		for j in GRID:
			var x0 := i * CELL - half
			var z0 := j * CELL - half
			var p00 := Vector3(x0, hgrid[i * w + j], z0)
			var p10 := Vector3(x0 + CELL, hgrid[(i + 1) * w + j], z0)
			var p01 := Vector3(x0, hgrid[i * w + j + 1], z0 + CELL)
			var p11 := Vector3(x0 + CELL, hgrid[(i + 1) * w + j + 1], z0 + CELL)
			var c00: Color = cols[i * w + j]
			var c10: Color = cols[(i + 1) * w + j]
			var c01: Color = cols[i * w + j + 1]
			var c11: Color = cols[(i + 1) * w + j + 1]
			add_tri(st, p00, p10, p01, c00, c10, c01)
			add_tri(st, p10, p11, p01, c10, c11, c01)
	st.generate_normals()
	var mesh := st.commit()
	var gm := StandardMaterial3D.new()
	gm.vertex_color_use_as_albedo = true
	gm.vertex_color_is_srgb = true
	gm.albedo_texture = make_detail_tex()
	gm.uv1_triplanar = true
	gm.uv1_world_triplanar = true
	gm.uv1_scale = Vector3(0.15, 0.15, 0.15)
	gm.roughness = 1.0
	gm.cull_mode = BaseMaterial3D.CULL_DISABLED
	mesh.surface_set_material(0, gm)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	add_child(mi)
	var body := StaticBody3D.new()
	body.collision_layer = 1
	var cs := CollisionShape3D.new()
	cs.shape = mesh.create_trimesh_shape()
	body.add_child(cs)
	add_child(body)


func build_sea() -> void:
	sea = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(700, 700)
	sea.mesh = pm
	sea_mat = StandardMaterial3D.new()
	sea_mat.albedo_color = Color(0.05, 0.26, 0.36, 0.8)
	sea_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sea_mat.roughness = 0.1
	sea_mat.metallic = 0.25
	sea_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	sea_mat.normal_enabled = true
	sea_mat.normal_texture = make_wave_normal()
	sea_mat.normal_scale = 0.7
	sea_mat.uv1_scale = Vector3(90, 90, 1)
	sea.material_override = sea_mat
	add_child(sea)


func build_map_texture() -> void:
	var sz := 160
	var img := Image.create(sz, sz, false, Image.FORMAT_RGB8)
	var half := world_size() * 0.5
	var step := world_size() / sz
	for ix in sz:
		for iz in sz:
			var x := (float(ix) + 0.5) * step - half
			var z := (float(iz) + 0.5) * step - half
			var h := height_at(x, z)
			var gx := height_at(x + step, z) - height_at(x - step, z)
			var gz := height_at(x, z + step) - height_at(x, z - step)
			var shade := clampf(1.0 - (gx + gz) * 0.06, 0.6, 1.35)
			var c: Color
			if h < 0.0:
				c = Color(0.05, 0.2, 0.42).lerp(Color(0.22, 0.58, 0.72), clampf((h + 7.0) / 7.0, 0.0, 1.0))
				shade = 1.0
			elif h < 0.9:
				c = Color(0.88, 0.8, 0.58)
			elif h > 15.0:
				c = Color(0.93, 0.95, 0.97)
			elif h > 10.0:
				c = Color(0.55, 0.52, 0.47)
			else:
				c = Color(0.30, 0.52, 0.22).lerp(Color(0.12, 0.32, 0.12), clampf(h / 10.0, 0.0, 1.0))
			c = Color(c.r * shade, c.g * shade, c.b * shade)
			if h >= 0.0 and h < 0.35:
				c = c.lerp(Color(1, 1, 1), 0.55)
			elif h >= 0.9 and fposmod(h, 3.0) < 0.12 + absf(gx + gz) * 0.02:
				c = c.darkened(0.15)
			img.set_pixel(ix, iz, c)
	map_tex = ImageTexture.create_from_image(img)
	hud.set_map_texture(map_tex)


func find_spawn() -> Vector3:
	for r in range(20, 60, 4):
		for a in 16:
			var ang := a * TAU / 16.0
			var x := cos(ang) * r
			var z := sin(ang) * r
			var h := height_at(x, z)
			if h > 1.4 and h < 2.6:
				return Vector3(x, h, z)
	return Vector3(0, height_at(0, 0), 0)


func rand_land_point(hmin: float, hmax: float, mind: float = 0.0) -> Vector3:
	for i in 100:
		var x := rng.randf_range(-ISLAND_R, ISLAND_R)
		var z := rng.randf_range(-ISLAND_R, ISLAND_R)
		var h := height_at(x, z)
		if h < hmin or h > hmax:
			continue
		if mind > 0.0 and Vector2(x - spawn_pos.x, z - spawn_pos.z).length() < mind:
			continue
		return Vector3(x, h, z)
	var fx := spawn_pos.x + 3.0
	return Vector3(fx, height_at(fx, spawn_pos.z), spawn_pos.z)


# =================================================================== world objects
func mat(c: Color, emit: bool = false) -> StandardMaterial3D:
	var key := c.to_html() + ("e" if emit else "")
	if mats.has(key):
		return mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 1.0
	if emit:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = 2.0
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mats[key] = m
	return m


func add_mesh(parent: Node, mesh: Mesh, c: Color, pos: Vector3 = Vector3.ZERO, vr: float = 0.0, emit: bool = false) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	m.material_override = mat(c, emit)
	m.position = pos
	if vr > 0.0:
		m.visibility_range_end = vr
	parent.add_child(m)
	return m


func box_mesh(s: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = s
	return b


func cyl_mesh(top: float, bottom: float, h: float, seg: int = 8) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = top
	c.bottom_radius = bottom
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	return c


func make_body(pos: Vector3, kind: String, hp: int, shape: Shape3D, shape_y: float) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.position = pos
	b.collision_layer = 4
	b.add_to_group("world_obj")
	b.add_to_group("interact")
	b.set_meta("kind", kind)
	b.set_meta("hp", hp)
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position.y = shape_y
	b.add_child(cs)
	add_child(b)
	return b


func build_tree_mesh() -> ArrayMesh:
	var am := ArrayMesh.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.append_from(cyl_mesh(0.16, 0.3, 2.8, 7), 0, Transform3D(Basis(), Vector3(0, 1.4, 0)))
	st.commit(am)
	var leaf := cyl_mesh(0.0, 1.5, 2.2, 8)
	leaf.cap_top = false
	var st2 := SurfaceTool.new()
	st2.begin(Mesh.PRIMITIVE_TRIANGLES)
	st2.append_from(leaf, 0, Transform3D(Basis(), Vector3(0, 2.7, 0)))
	st2.append_from(leaf, 0, Transform3D(Basis().scaled(Vector3(0.78, 0.78, 0.78)), Vector3(0, 3.9, 0)))
	st2.append_from(leaf, 0, Transform3D(Basis().scaled(Vector3(0.56, 0.56, 0.56)), Vector3(0, 5.0, 0)))
	st2.commit(am)
	am.surface_set_material(0, mat(Color(0.30, 0.20, 0.12)))
	var lm := StandardMaterial3D.new()
	lm.albedo_color = Color(1, 1, 1)
	lm.vertex_color_use_as_albedo = true
	lm.roughness = 1.0
	am.surface_set_material(1, lm)
	return am


func pick_spread(list: Array, maxn: int) -> Array:
	if list.size() <= maxn:
		return list
	var out: Array = []
	var step := float(list.size()) / maxn
	for i in maxn:
		out.append(list[int(i * step)])
	return out


func is_mostly_white(mesh: Mesh) -> bool:
	var total := 0
	var white := 0
	for i in mesh.get_surface_count():
		var arr := mesh.surface_get_arrays(i)
		var n: int = arr[Mesh.ARRAY_VERTEX].size()
		total += n
		var mt = mesh.surface_get_material(i)
		if mt is StandardMaterial3D:
			var c: Color = mt.albedo_color
			if minf(c.r, minf(c.g, c.b)) > 0.7:
				white += n
	return total > 0 and white * 2 > total


func tune_mesh(mesh: Mesh, light: float) -> void:
	for i in mesh.get_surface_count():
		var mt = mesh.surface_get_material(i)
		if mt is StandardMaterial3D:
			mt.roughness = 1.0
			mt.metallic = 0.0
			mt.metallic_specular = 0.0
			if light > 0.0:
				mt.albedo_color = mt.albedo_color.lightened(light)
			elif light < 0.0:
				mt.albedo_color = mt.albedo_color.darkened(-light)


func animal_kind(low: String) -> String:
	var keys := {"rabbit": ["rabbit", "bunny"], "deer": ["deer", "stag"], "boar": ["boar", "pig", "hog"], "wolf": ["wolf"], "fox": ["fox"]}
	for k in keys:
		for w in keys[k]:
			if w in low:
				return k
	return ""


func scan_models() -> void:
	model_animals = {}
	model_trees = []
	model_rocks = []
	model_bushes = []
	if not DirAccess.dir_exists_absolute("res://models"):
		return
	var files := DirAccess.get_files_at("res://models")
	var seen := {}
	var names: Array = []
	for f in files:
		var n: String = f
		for suf in [".import", ".remap"]:
			if n.ends_with(suf):
				n = n.substr(0, n.length() - suf.length())
		var nl := n.to_lower()
		if (nl.ends_with(".obj") or nl.ends_with(".glb") or nl.ends_with(".gltf")) and not seen.has(n):
			seen[n] = true
			names.append(n)
	names.sort()
	for n in names:
		var low: String = n.to_lower()
		var bad := false
		for w in ["dead", "stump", "log", "trunk", "cactus", "palm", "snow", "twisted"]:
			if w in low:
				bad = true
		if bad:
			continue
		var res = load("res://models/" + n)
		var akind := animal_kind(low)
		if akind != "":
			if res is PackedScene or res is Mesh:
				if not model_animals.has(akind):
					model_animals[akind] = []
				model_animals[akind].append(res)
			continue
		if not (res is Mesh):
			continue
		if "tree" in low or "willow" in low:
			if is_mostly_white(res):
				continue
			tune_mesh(res, 0.12)
			model_trees.append(res)
		elif "rock" in low:
			tune_mesh(res, -0.25)
			model_rocks.append(res)
		elif "bush" in low:
			if is_mostly_white(res):
				continue
			tune_mesh(res, 0.08)
			model_bushes.append(res)
	model_trees = pick_spread(model_trees, 8)
	model_rocks = pick_spread(model_rocks, 5)
	model_bushes = pick_spread(model_bushes, 3)
	print("Animal models: ", model_animals.keys())
	print("Models loaded: trees=", model_trees.size(), " rocks=", model_rocks.size(), " bushes=", model_bushes.size())


func populate_world() -> void:
	var old: Array = get_tree().get_nodes_in_group("world_obj")
	for n in old:
		n.queue_free()
	rng.seed = WORLD_SEED
	# ---- trees (one MultiMesh per model variant = few draw calls)
	var tp: Array = []
	var tries := 0
	while tp.size() < 140 and tries < 3000:
		tries += 1
		var x := rng.randf_range(-ISLAND_R, ISLAND_R)
		var z := rng.randf_range(-ISLAND_R, ISLAND_R)
		var h := height_at(x, z)
		if h < 1.7 or h > 11.5:
			continue
		if Vector2(x - spawn_pos.x, z - spawn_pos.z).length() < 6.0:
			continue
		tp.append(Vector3(x, h, z))
	var tvars: Array = []
	var tscale: Array = []
	var toff: Array = []
	var use_models := model_trees.size() > 0
	if use_models:
		for mdl in model_trees:
			var bb: AABB = mdl.get_aabb()
			tvars.append(mdl)
			tscale.append(7.0 / maxf(bb.size.y, 0.01))
			toff.append(-bb.position.y)
	else:
		if tree_mesh == null:
			tree_mesh = build_tree_mesh()
		tvars.append(tree_mesh)
		tscale.append(1.0)
		toff.append(0.0)
	var tinfo: Array = []
	var tcount: Array = []
	for k in tvars.size():
		tcount.append(0)
	for i in tp.size():
		var vsel := int(rng.randi() % tvars.size())
		tinfo.append(vsel)
		tcount[vsel] += 1
	var mms: Array = []
	var fill: Array = []
	for k in tvars.size():
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		if not use_models:
			mm.use_colors = true
		mm.mesh = tvars[k]
		mm.instance_count = int(tcount[k])
		mms.append(mm)
		fill.append(0)
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.add_to_group("world_obj")
		add_child(mmi)
	var tshape := CylinderShape3D.new()
	tshape.radius = 0.4
	tshape.height = 2.4
	for i in tp.size():
		var p: Vector3 = tp[i]
		var vi: int = tinfo[i]
		var s := rng.randf_range(0.85, 1.3) * float(tscale[vi])
		var b := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s, s))
		var idx: int = fill[vi]
		fill[vi] = idx + 1
		var tmm: MultiMesh = mms[vi]
		tmm.set_instance_transform(idx, Transform3D(b, p + Vector3(0, float(toff[vi]) * s, 0)))
		if not use_models:
			tmm.set_instance_color(idx, Color(rng.randf_range(0.10, 0.20), rng.randf_range(0.28, 0.42), rng.randf_range(0.08, 0.16)))
		var body := make_body(p, "tree", 4, tshape, 1.2)
		body.set_meta("idx", idx)
		body.set_meta("mm", tmm)
	# ---- grass blades (one draw call)
	var gl: Array = []
	var gt := 0
	while gl.size() < 6000 and gt < 16000:
		gt += 1
		var gx := rng.randf_range(-ISLAND_R, ISLAND_R)
		var gz := rng.randf_range(-ISLAND_R, ISLAND_R)
		var gh := height_at(gx, gz)
		if gh < 1.3 or gh > 9.5:
			continue
		gl.append(Vector3(gx, gh, gz))
	var gmesh := cyl_mesh(0.0, 0.035, 0.35, 3)
	var gmat := StandardMaterial3D.new()
	gmat.albedo_color = Color(1, 1, 1)
	gmat.vertex_color_use_as_albedo = true
	gmat.roughness = 1.0
	gmesh.material = gmat
	var gmm := MultiMesh.new()
	gmm.transform_format = MultiMesh.TRANSFORM_3D
	gmm.use_colors = true
	gmm.mesh = gmesh
	gmm.instance_count = gl.size()
	for i in gl.size():
		var gp: Vector3 = gl[i]
		var gs := rng.randf_range(0.7, 1.4)
		var gb := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(gs, gs, gs))
		gb = gb * Basis(Vector3.RIGHT, rng.randf_range(-0.25, 0.25))
		gmm.set_instance_transform(i, Transform3D(gb, gp + Vector3(0, 0.22 * gs, 0)))
		gmm.set_instance_color(i, Color(rng.randf_range(0.14, 0.30), rng.randf_range(0.30, 0.42), rng.randf_range(0.08, 0.14)))
	grass_node = MultiMeshInstance3D.new()
	grass_node.multimesh = gmm
	grass_node.add_to_group("world_obj")
	add_child(grass_node)
	# ---- rocks
	var rshape := SphereShape3D.new()
	rshape.radius = 0.75
	for i in 45:
		var p := rand_land_point(0.9, 14.0, 4.0)
		var body := make_body(p, "rock", 3, rshape, 0.45)
		if model_rocks.size() > 0:
			var rm: Mesh = model_rocks[int(rng.randi() % model_rocks.size())]
			var rb: AABB = rm.get_aabb()
			var rs := rng.randf_range(1.2, 2.2) / maxf(maxf(rb.size.x, rb.size.z), 0.01)
			var rmi := MeshInstance3D.new()
			rmi.mesh = rm
			rmi.position = Vector3(0, -rb.position.y * rs, 0)
			rmi.scale = Vector3(rs, rs, rs)
			rmi.rotation.y = rng.randf() * TAU
			rmi.visibility_range_end = 120.0
			body.add_child(rmi)
		else:
			var sm := SphereMesh.new()
			sm.radius = 0.8
			sm.height = 1.1
			sm.radial_segments = 6
			sm.rings = 3
			var mi := add_mesh(body, sm, Color(0.5, 0.5, 0.52).lerp(Color(0.35, 0.35, 0.38), rng.randf()), Vector3(0, 0.4, 0), 120.0)
			mi.scale = Vector3(rng.randf_range(0.8, 1.3), rng.randf_range(0.7, 1.1), rng.randf_range(0.8, 1.3))
			mi.rotation.y = rng.randf() * TAU
	# ---- berry bushes
	var bshape := SphereShape3D.new()
	bshape.radius = 0.6
	for i in 24:
		var p := rand_land_point(1.6, 7.0, 3.0)
		var body := make_body(p, "bush", 1, bshape, 0.45)
		if model_bushes.size() > 0:
			var bmod: Mesh = model_bushes[int(rng.randi() % model_bushes.size())]
			var bbb: AABB = bmod.get_aabb()
			var bs := rng.randf_range(1.1, 1.6) / maxf(maxf(bbb.size.x, bbb.size.z), 0.01)
			var bmi := MeshInstance3D.new()
			bmi.mesh = bmod
			bmi.position = Vector3(0, -bbb.position.y * bs, 0)
			bmi.scale = Vector3(bs, bs, bs)
			bmi.rotation.y = rng.randf() * TAU
			bmi.visibility_range_end = 100.0
			body.add_child(bmi)
		else:
			var bm := SphereMesh.new()
			bm.radius = 0.7
			bm.height = 1.0
			bm.radial_segments = 6
			bm.rings = 3
			add_mesh(body, bm, Color(0.15, 0.45, 0.15), Vector3(0, 0.45, 0), 100.0)
		var berries := Node3D.new()
		body.add_child(berries)
		var brm := SphereMesh.new()
		brm.radius = 0.12
		brm.height = 0.24
		brm.radial_segments = 5
		brm.rings = 3
		for k in 3:
			var a := rng.randf() * TAU
			add_mesh(berries, brm, Color(0.85, 0.1, 0.15), Vector3(cos(a) * 0.55, 0.55 + rng.randf() * 0.3, sin(a) * 0.55), 60.0)
		body.set_meta("berries", berries)
		body.set_meta("ready", true)
	# ---- animals
	for i in 8:
		spawn_animal("rabbit", rand_land_point(1.6, 8.0, 10.0))
	for i in 5:
		spawn_animal("deer", rand_land_point(1.6, 8.0, 14.0))
	for i in 3:
		spawn_animal("boar", rand_land_point(1.6, 8.0, 18.0))
	for i in 3:
		spawn_animal("wolf", rand_land_point(1.6, 9.0, 28.0))
	for i in 3:
		spawn_animal("fox", rand_land_point(1.6, 8.0, 14.0))
	for i in 6:
		spawn_animal("bird", rand_land_point(1.6, 9.0, 0.0))
	# ---- ruins and hermit camp
	ruins_pos = rand_land_point(7.0, 13.0, 20.0)
	build_ruins(ruins_pos)
	camp_pos = rand_land_point(1.8, 4.0, 18.0)
	build_camp(camp_pos)


func spawn_animal(kind: String, p: Vector3) -> void:
	var a = AnimalScript.new()
	a.add_to_group("world_obj")
	add_child(a)
	a.setup(kind, self, p)


func build_ruins(p: Vector3) -> void:
	var r := Node3D.new()
	r.position = p
	r.add_to_group("world_obj")
	add_child(r)
	for i in 8:
		var a := i * TAU / 8.0
		var hgt := rng.randf_range(2.0, 4.0)
		var pil := add_mesh(r, cyl_mesh(0.4, 0.45, hgt, 8), Color(0.62, 0.6, 0.55), Vector3(cos(a) * 5.0, hgt * 0.5, sin(a) * 5.0), 150.0)
		if i % 3 == 0:
			pil.rotation_degrees = Vector3(rng.randf_range(-25, 25), 0, rng.randf_range(-25, 25))
	add_mesh(r, box_mesh(Vector3(2.0, 1.0, 1.2)), Color(0.55, 0.53, 0.5), Vector3(0, 0.5, 0), 150.0)
	add_mesh(r, box_mesh(Vector3(1.4, 0.5, 0.6)), Color(0.5, 0.48, 0.45), Vector3(2.4, 0.25, 1.2), 150.0)


func build_shelter_node(col: Color) -> Node3D:
	var n := Node3D.new()
	var roof_l := add_mesh(n, box_mesh(Vector3(3.2, 0.15, 3.0)), col, Vector3(-0.9, 1.2, 0), 120.0)
	roof_l.rotation_degrees.z = 50.0
	var roof_r := add_mesh(n, box_mesh(Vector3(3.2, 0.15, 3.0)), col, Vector3(0.9, 1.2, 0), 120.0)
	roof_r.rotation_degrees.z = -50.0
	add_mesh(n, box_mesh(Vector3(3.2, 1.8, 0.12)), col.darkened(0.2), Vector3(0, 0.9, -1.5), 120.0)
	add_mesh(n, cyl_mesh(1.3, 1.3, 0.06, 10), Color(0.75, 0.65, 0.3), Vector3(0, 0.03, 0), 120.0)
	return n


func build_campfire_node(real: bool) -> Node3D:
	var n := Node3D.new()
	for i in 8:
		var a := i * TAU / 8.0
		var sm := SphereMesh.new()
		sm.radius = 0.18
		sm.height = 0.3
		sm.radial_segments = 5
		sm.rings = 3
		add_mesh(n, sm, Color(0.5, 0.5, 0.52), Vector3(cos(a) * 0.6, 0.12, sin(a) * 0.6), 80.0)
	var l1 := add_mesh(n, box_mesh(Vector3(0.15, 0.15, 1.1)), Color(0.35, 0.22, 0.1), Vector3(0, 0.2, 0), 80.0)
	l1.rotation_degrees.y = 30.0
	var l2 := add_mesh(n, box_mesh(Vector3(0.15, 0.15, 1.1)), Color(0.35, 0.22, 0.1), Vector3(0, 0.25, 0), 80.0)
	l2.rotation_degrees.y = -40.0
	add_mesh(n, cyl_mesh(0.0, 0.3, 0.8, 6), Color(1.0, 0.55, 0.1), Vector3(0, 0.55, 0), 80.0, true)
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.6, 0.25)
	light.omni_range = 10.0
	light.light_energy = 1.6
	light.position = Vector3(0, 1.0, 0)
	n.add_child(light)
	n.set_meta("light", light)
	if real:
		n.add_to_group("interact")
		n.add_to_group("fires")
		n.set_meta("kind", "fire")
	return n


func build_camp(p: Vector3) -> void:
	var camp := build_shelter_node(Color(0.6, 0.25, 0.2))
	camp.position = p
	camp.add_to_group("world_obj")
	add_child(camp)
	var fire := build_campfire_node(false)
	fire.position = p + Vector3(3.0, 0.0, 1.0)
	fire.position.y = height_at(fire.position.x, fire.position.z)
	fire.add_to_group("world_obj")
	add_child(fire)
	var crate := Node3D.new()
	crate.position = p + Vector3(-2.5, 0.0, 1.5)
	crate.add_to_group("world_obj")
	add_child(crate)
	add_mesh(crate, box_mesh(Vector3(0.8, 0.8, 0.8)), Color(0.5, 0.35, 0.18), Vector3(0, 0.4, 0), 100.0)
	# hermit NPC
	var npc := Node3D.new()
	npc.position = p + Vector3(1.5, 0.0, 2.5)
	npc.position.y = height_at(npc.position.x, npc.position.z)
	npc.add_to_group("world_obj")
	npc.add_to_group("interact")
	npc.set_meta("kind", "npc")
	add_child(npc)
	add_mesh(npc, cyl_mesh(0.3, 0.5, 1.3, 8), Color(0.45, 0.3, 0.2), Vector3(0, 0.65, 0), 100.0)
	add_mesh(npc, box_mesh(Vector3(0.3, 0.3, 0.3)), Color(0.85, 0.68, 0.52), Vector3(0, 1.45, 0), 100.0)
	add_mesh(npc, box_mesh(Vector3(0.34, 0.2, 0.34)), Color(0.85, 0.85, 0.85), Vector3(0, 1.28, 0.05), 100.0)
	add_mesh(npc, cyl_mesh(0.02, 0.05, 1.6, 5), Color(0.4, 0.28, 0.15), Vector3(0.45, 0.8, 0.1), 100.0)


func spawn_structure(t: String, p: Vector3, rot: float) -> void:
	var n: Node3D
	match t:
		"campfire":
			n = build_campfire_node(true)
		"shelter":
			n = build_shelter_node(Color(0.5, 0.35, 0.18))
			n.add_to_group("interact")
			n.add_to_group("shelters")
			n.set_meta("kind", "shelter")
		"box":
			n = Node3D.new()
			add_mesh(n, box_mesh(Vector3(1.0, 0.7, 0.7)), Color(0.5, 0.33, 0.15), Vector3(0, 0.35, 0), 100.0)
			add_mesh(n, box_mesh(Vector3(1.05, 0.1, 0.75)), Color(0.35, 0.22, 0.1), Vector3(0, 0.72, 0), 100.0)
			n.add_to_group("interact")
			n.set_meta("kind", "box")
		_:
			return
	n.position = p
	n.rotation.y = rot
	n.add_to_group("world_obj")
	add_child(n)


func place_structure(t: String) -> bool:
	var p: Vector3 = player.global_position + player.face * 2.6
	p.y = height_at(p.x, p.z)
	if p.y < 0.7:
		toast("You can't build in water!")
		return false
	var rot: float = player.model.rotation.y
	spawn_structure(t, p, rot)
	structures.append({"t": t, "p": p, "r": rot})
	return true


# =================================================================== audio
func make_stream(data: PackedFloat32Array, rate: int, loop: bool) -> AudioStreamWAV:
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = rate
	s.stereo = false
	var bytes := PackedByteArray()
	bytes.resize(data.size() * 2)
	for i in data.size():
		bytes.encode_s16(i * 2, int(clampf(data[i], -1.0, 1.0) * 30000.0))
	s.data = bytes
	if loop:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = data.size()
	return s


func make_sfx(kind: String) -> AudioStreamWAV:
	var rate := 22050
	var dur := 0.18
	if kind == "thunder" or kind == "howl":
		dur = 1.8
	elif kind == "chirp":
		dur = 0.22
	var n := int(rate * dur)
	var d := PackedFloat32Array()
	d.resize(n)
	var y := 0.0
	var ph := 0.0
	for i in n:
		var t := float(i) / rate
		var v := 0.0
		match kind:
			"chop":
				y += (randf() * 2.0 - 1.0 - y) * 0.25
				v = y * exp(-t * 18.0) * 2.2
			"pick":
				v = sin(TAU * 660.0 * t) * exp(-t * 14.0) * 0.6
			"hurt":
				v = sin(TAU * 140.0 * t) * exp(-t * 10.0) * 0.9 + (randf() - 0.5) * 0.2 * exp(-t * 18.0)
			"step":
				y += (randf() * 2.0 - 1.0 - y) * 0.12
				v = y * exp(-t * 35.0) * 2.5
			"thunder":
				y += (randf() * 2.0 - 1.0 - y) * 0.04
				v = y * exp(-t * 1.5) * 7.0
			"howl":
				ph += TAU * (330.0 + 120.0 * sin(PI * t / dur)) / rate
				v = sin(ph + 0.6 * sin(TAU * 6.0 * t)) * sin(PI * t / dur) * 0.5
			"chirp":
				ph += TAU * (2600.0 + 900.0 * t / dur) / rate
				v = sin(ph) * exp(-t * 12.0) * 0.35
		d[i] = v
	return make_stream(d, rate, false)


func make_loop(kind: String) -> AudioStreamWAV:
	var rate := 22050
	var n := rate * 2
	if kind == "music":
		rate = 11025
		n = rate * 8
	var d := PackedFloat32Array()
	d.resize(n)
	var y := 0.0
	for i in n:
		var t := float(i) / rate
		var v := 0.0
		match kind:
			"rain":
				y += (randf() * 2.0 - 1.0 - y) * 0.45
				v = y * 0.9
			"wind":
				y += (randf() * 2.0 - 1.0 - y) * 0.015
				v = y * 9.0 * (0.6 + 0.4 * sin(TAU * float(i) / n))
			"music":
				var am := 0.5 + 0.5 * sin(TAU * t / 8.0)
				v = (sin(TAU * 110.0 * t) * 0.5 + sin(TAU * 165.0 * t) * 0.3 + sin(TAU * 220.0 * t) * 0.2) * am * 0.5
		d[i] = v
	return make_stream(d, rate, true)


func build_audio() -> void:
	for k in ["chop", "pick", "hurt", "step", "thunder", "howl", "chirp"]:
		sfx_streams[k] = make_sfx(k)
	for i in 4:
		var p := AudioStreamPlayer.new()
		add_child(p)
		sfx_pool.append(p)
	rain_audio = AudioStreamPlayer.new()
	rain_audio.stream = make_loop("rain")
	rain_audio.volume_db = -80.0
	add_child(rain_audio)
	rain_audio.play()
	wind_audio = AudioStreamPlayer.new()
	wind_audio.stream = make_loop("wind")
	wind_audio.volume_db = linear_to_db(0.12)
	add_child(wind_audio)
	wind_audio.play()
	music_audio = AudioStreamPlayer.new()
	music_audio.stream = make_loop("music")
	music_audio.volume_db = linear_to_db(0.14)
	add_child(music_audio)
	music_audio.play()


func play_sfx(k: String) -> void:
	if sfx_pool.is_empty() or not sfx_streams.has(k):
		return
	var p: AudioStreamPlayer = sfx_pool[sfx_i]
	sfx_i = (sfx_i + 1) % sfx_pool.size()
	p.stream = sfx_streams[k]
	var vols := {"step": -8.0, "howl": -6.0, "chirp": -10.0}
	p.volume_db = float(vols.get(k, 0.0))
	p.play()


# =================================================================== settings
func load_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return
	var d = JSON.parse_string(FileAccess.get_file_as_string(SETTINGS_PATH))
	if typeof(d) == TYPE_DICTIONARY:
		settings["quality"] = clampi(int(d.get("quality", 1)), 0, 2)
		settings["volume"] = clampf(float(d.get("volume", 0.8)), 0.0, 1.0)
		settings["ai"] = bool(d.get("ai", false))


func save_settings() -> void:
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))
		f.close()


func set_quality(q: int) -> void:
	settings["quality"] = q
	apply_quality(q)
	save_settings()
	hud.refresh_settings()


func apply_quality(q: int) -> void:
	q = clampi(q, 0, 2)
	var far_d := [150.0, 240.0, 400.0]
	var rain_n := [150, 280, 450]
	var fps := [30, 60, 60]
	sun.shadow_enabled = q > 0
	if q == 1:
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
		sun.directional_shadow_max_distance = 60.0
	elif q == 2:
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		sun.directional_shadow_max_distance = 110.0
	menu_cam.far = far_d[q]
	if player != null:
		player.cam.far = far_d[q]
	rain.amount = rain_n[q]
	if grass_node != null and is_instance_valid(grass_node):
		grass_node.visible = q > 0
	Engine.max_fps = fps[q]


func set_volume(v: float) -> void:
	settings["volume"] = v
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(v, 0.0001)))
	save_settings()


func toggle_ai() -> void:
	settings["ai"] = not settings["ai"]
	save_settings()
	hud.refresh_settings()


# =================================================================== panels / state
func open_panel(n: String) -> void:
	if state == "play":
		state = "paused"
	hud.show_panel(n)


func close_panel() -> void:
	if state == "paused":
		state = "play"
		hud.show_panel("")


func settings_back() -> void:
	if state == "menu":
		hud.show_panel("menu")
	else:
		hud.show_panel("pause")


func handle_back() -> void:
	if state == "play":
		open_panel("pause")
	elif state == "paused":
		if hud.modal == "settings":
			hud.show_panel("pause")
		else:
			close_panel()
	elif state == "menu":
		if hud.modal == "settings":
			hud.show_panel("menu")


func _notification(what: int) -> void:
	if hud == null:
		return
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if state == "play" or state == "paused":
			save_game()
		if what == NOTIFICATION_APPLICATION_PAUSED and state == "play":
			open_panel("pause")
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		handle_back()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_E:
				do_interact()
			KEY_F:
				do_attack()
			KEY_SPACE:
				if state == "play":
					player.want_jump = true
			KEY_ESCAPE:
				handle_back()
			KEY_I:
				if state == "play":
					open_panel("inventory")
			KEY_C:
				if state == "play":
					open_panel("craft")


func toast(t: String, secs: float = 2.5) -> void:
	hud.toast(t, secs)


func reset_state() -> void:
	stats = {"hp": 100.0, "stamina": 100.0, "hunger": 100.0, "thirst": 100.0}
	inv = {}
	box_store = {}
	xp = 0
	level = 1
	mission_idx = 0
	counters = {"wood": 0, "stone": 0, "fire": 0, "shelter": 0, "kills": 0, "food": 0, "ruins": 0}
	achievements = {}
	bonus = {}
	structures = []
	day = 1
	time_of_day = 0.30
	raining = false
	rain_f = 0.0
	rain_timer = 50.0
	player.run_on = false
	player.yaw = 0.0
	player.pitch = -0.3
	player.velocity = Vector3.ZERO
	player.position = spawn_pos + Vector3(0, 1.5, 0)


func start_game(load_it: bool) -> void:
	state = "loading"
	hud.show_panel("loading")
	hud.set_loading("Loading world...")
	await get_tree().process_frame
	await get_tree().process_frame
	if world_dirty:
		populate_world()
	world_dirty = true
	reset_state()
	if load_it and has_save():
		load_game()
	player.cam.make_current()
	apply_quality(int(settings["quality"]))
	update_sky()
	state = "play"
	hud.show_panel("")
	check_missions()
	push_hud()
	if not load_it:
		toast("Welcome, survivor! Walk to a tree and tap INTERACT to collect wood.", 6.0)


func go_to_menu() -> void:
	save_game()
	state = "menu"
	menu_cam.make_current()
	hud.show_panel("menu")


func manual_save() -> void:
	save_game()
	toast("Game saved.")


func respawn() -> void:
	stats = {"hp": 70.0, "stamina": 100.0, "hunger": 60.0, "thirst": 60.0}
	player.velocity = Vector3.ZERO
	player.position = spawn_pos + Vector3(0, 1.5, 0)
	state = "play"
	hud.show_panel("")
	toast("You wake up on the beach...")


func die() -> void:
	stats["hp"] = 0.0
	state = "dead"
	hud.show_panel("dead")


func damage_player(d: float) -> void:
	if state != "play":
		return
	stats["hp"] -= d
	play_sfx("hurt")
	hud.flash()
	if stats["hp"] <= 0.0:
		die()


# =================================================================== save / load
func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_game() -> void:
	if player == null or state == "loading" or state == "menu":
		return
	var sl := []
	for s in structures:
		var sp: Vector3 = s["p"]
		sl.append({"t": s["t"], "p": [sp.x, sp.y, sp.z], "r": s["r"]})
	var pp: Vector3 = player.global_position
	var d := {
		"v": 1,
		"pos": [pp.x, pp.y, pp.z],
		"stats": stats,
		"inv": inv,
		"box": box_store,
		"xp": xp,
		"level": level,
		"mission": mission_idx,
		"counters": counters,
		"day": day,
		"tod": time_of_day,
		"structures": sl,
		"ach": achievements,
		"bonus": bonus,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))
		f.close()


func load_game() -> void:
	var d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if typeof(d) != TYPE_DICTIONARY:
		return
	var pa: Array = d.get("pos", [spawn_pos.x, spawn_pos.y, spawn_pos.z])
	player.position = Vector3(float(pa[0]), float(pa[1]) + 0.5, float(pa[2]))
	var st: Dictionary = d.get("stats", {})
	for k in st:
		stats[k] = float(st[k])
	var iv: Dictionary = d.get("inv", {})
	for k in iv:
		inv[k] = int(iv[k])
	var bx: Dictionary = d.get("box", {})
	for k in bx:
		box_store[k] = int(bx[k])
	xp = int(d.get("xp", 0))
	level = int(d.get("level", 1))
	mission_idx = int(d.get("mission", 0))
	var ct: Dictionary = d.get("counters", {})
	for k in ct:
		counters[k] = int(ct[k])
	day = int(d.get("day", 1))
	time_of_day = float(d.get("tod", 0.3))
	achievements = d.get("ach", {})
	var bn = d.get("bonus", {})
	if typeof(bn) == TYPE_DICTIONARY and not bn.is_empty():
		bonus = {"t": str(bn["t"]), "k": str(bn["k"]), "base": int(bn["base"]), "need": int(bn["need"]), "xp": int(bn["xp"])}
	var sl: Array = d.get("structures", [])
	for s in sl:
		var sp: Array = s["p"]
		var v := Vector3(float(sp[0]), float(sp[1]), float(sp[2]))
		var rot := float(s["r"])
		spawn_structure(str(s["t"]), v, rot)
		structures.append({"t": str(s["t"]), "p": v, "r": rot})


# =================================================================== game loop
func advance_clock(delta: float, real: bool) -> void:
	time_of_day += delta / DAY_LENGTH
	if time_of_day >= 1.0:
		time_of_day -= 1.0
		if real:
			day += 1
			toast("Day %d begins." % day, 3.0)
			check_missions()


func update_sky() -> void:
	var elev := sin((time_of_day - 0.25) * TAU)
	var day_f := clampf(elev * 2.5 + 0.35, 0.0, 1.0)
	var dusk := clampf(1.0 - absf(elev) * 5.0, 0.0, 1.0)
	var top := Color(0.02, 0.03, 0.10).lerp(Color(0.22, 0.48, 0.85), day_f)
	var hor := Color(0.05, 0.07, 0.15).lerp(Color(0.72, 0.84, 0.94), day_f).lerp(Color(1.0, 0.58, 0.28), dusk * 0.85)
	var grey := Color(0.34, 0.37, 0.40).lerp(Color(0.04, 0.05, 0.07), 1.0 - day_f)
	top = top.lerp(grey, rain_f * 0.85)
	hor = hor.lerp(grey, rain_f * 0.9)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = hor.darkened(0.5)
	env.fog_light_color = hor
	env.fog_density = lerpf(0.0028, 0.02, rain_f)
	env.ambient_light_color = Color(0.20, 0.24, 0.42).lerp(Color(0.70, 0.72, 0.68), day_f)
	env.ambient_light_energy = lerpf(0.95, 0.75, day_f) * lerpf(1.0, 0.7, rain_f)
	sun.rotation_degrees.x = -maxf(elev, 0.04) * 80.0
	sun.light_energy = clampf(elev * 2.0 + 0.35, 0.0, 1.0) * 0.85 * lerpf(1.0, 0.35, rain_f)
	sun.light_color = Color(1, 1, 1).lerp(Color(1.0, 0.65, 0.4), dusk)
	moon.light_energy = (1.0 - day_f) * 0.6


func is_night() -> bool:
	return time_of_day > 0.76 or time_of_day < 0.24


func _process(delta: float) -> void:
	if sea_mat != null:
		sea_mat.uv1_offset += Vector3(delta * 0.012, delta * 0.007, 0.0)
	if state == "menu":
		menu_angle += delta * 0.08
		menu_cam.look_at_from_position(Vector3(cos(menu_angle) * 100.0, 48.0, sin(menu_angle) * 100.0), Vector3(0, 2, 0))
		advance_clock(delta * 0.3, false)
		update_sky()
		return
	if state != "play":
		return
	t_total += delta
	advance_clock(delta, true)
	update_sky()
	update_weather(delta)
	update_ambient(delta)
	update_survival(delta)
	rain.global_position = player.global_position + Vector3(0, 12, 0)
	sea.position.y = sin(t_total * 0.8) * 0.06
	var fl: Array = get_tree().get_nodes_in_group("fires")
	for i in fl.size():
		var lt = fl[i].get_meta("light")
		lt.light_energy = 1.5 + sin(t_total * 13.0 + i) * 0.3
	if player.moving and player.is_on_floor():
		step_t -= delta
		if step_t <= 0.0:
			step_t = 0.28 if player.sprinting else 0.45
			play_sfx("step")
	tick += delta
	if tick >= 0.2:
		tick = 0.0
		periodic()
	autosave_t += delta
	if autosave_t > 30.0:
		autosave_t = 0.0
		save_game()


func periodic() -> void:
	player_safe = is_safe(player.global_position)
	hud.set_hint(current_hint())
	push_hud()
	if counters["ruins"] == 0 and player.global_position.distance_to(ruins_pos) < 12.0:
		counters["ruins"] = 1
		toast("You discovered the Ancient Ruins!", 4.0)
		give_xp(30)
		ach("ruins", "Explorer")
		check_missions()
	if player.global_position.y < -3.0:
		player.velocity = Vector3.ZERO
		player.position = spawn_pos + Vector3(0, 1.5, 0)
		toast("The waves washed you back to shore.")
		damage_player(5.0)


func push_hud() -> void:
	hud.update_stats(stats, xp, level, day, time_of_day, raining)


func update_ambient(delta: float) -> void:
	amb_t -= delta
	if amb_t <= 0.0:
		amb_t = randf_range(8.0, 20.0)
		if is_night():
			play_sfx("howl")
		elif not raining and randf() < 0.7:
			play_sfx("chirp")
	if rain_f > 0.7:
		thunder_t -= delta
		if thunder_t <= 0.0:
			thunder_t = randf_range(15.0, 35.0)
			flash_t = 0.25
			get_tree().create_timer(randf_range(0.4, 1.6)).timeout.connect(play_sfx.bind("thunder"))
	if flash_t > 0.0:
		flash_t -= delta
		env.ambient_light_energy += 2.5 * maxf(flash_t, 0.0) / 0.25


func update_weather(delta: float) -> void:
	rain_timer -= delta
	if rain_timer <= 0.0:
		if raining:
			raining = false
		elif randf() < 0.45:
			raining = true
		rain_timer = randf_range(40.0, 100.0)
	rain_f = move_toward(rain_f, 1.0 if raining else 0.0, delta * 0.2)
	rain.emitting = rain_f > 0.03
	rain_audio.volume_db = linear_to_db(maxf(rain_f * 0.5, 0.0001))


func update_survival(delta: float) -> void:
	var sprint: bool = player.sprinting
	var mv: bool = player.moving
	if sprint:
		stats["stamina"] -= 14.0 * delta
	elif mv:
		stats["stamina"] += 6.0 * delta
	else:
		stats["stamina"] += 14.0 * delta
	stats["stamina"] = clampf(stats["stamina"], 0.0, 100.0)
	if stats["stamina"] <= 0.0 and player.run_on:
		player.run_on = false
		hud.update_run()
	var mult := 1.4 if sprint else 1.0
	stats["hunger"] = maxf(0.0, stats["hunger"] - 0.18 * mult * delta)
	stats["thirst"] = maxf(0.0, stats["thirst"] - 0.26 * mult * delta)
	if stats["hunger"] <= 0.0 or stats["thirst"] <= 0.0:
		stats["hp"] -= 2.0 * delta
	elif stats["hunger"] > 40.0 and stats["thirst"] > 40.0:
		stats["hp"] = minf(100.0, stats["hp"] + 0.8 * delta)
	if player_safe:
		stats["hp"] = minf(100.0, stats["hp"] + 1.5 * delta)
	if stats["hp"] <= 0.0:
		die()


func is_safe(pos: Vector3) -> bool:
	var fl: Array = get_tree().get_nodes_in_group("fires")
	for f in fl:
		if pos.distance_to(f.global_position) < 7.0:
			return true
	return false


# =================================================================== interaction
func is_at_water() -> bool:
	var p: Vector3 = player.global_position
	return height_at(p.x, p.z) < 0.9


func nearest_interactable():
	var best = null
	var bd := 3.2
	var pp: Vector3 = player.global_position
	var list: Array = get_tree().get_nodes_in_group("interact")
	for n in list:
		if not is_instance_valid(n) or n.is_queued_for_deletion():
			continue
		var d := pp.distance_to(n.global_position)
		if d < bd:
			bd = d
			best = n
	return best


func current_hint() -> String:
	var n = nearest_interactable()
	if n == null:
		return "Drink" if is_at_water() else "Interact"
	var k: String = n.get_meta("kind")
	match k:
		"tree":
			return "Chop"
		"rock":
			return "Mine"
		"bush":
			return "Pick"
		"fire":
			return "Cook"
		"shelter":
			return "Sleep"
		"box":
			return "Storage"
		"npc":
			return "Talk"
	return "Use"


func do_interact() -> void:
	if state != "play":
		return
	var n = nearest_interactable()
	if n == null:
		if is_at_water():
			stats["thirst"] = minf(100.0, stats["thirst"] + 30.0)
			play_sfx("pick")
			toast("You drink some water.")
		else:
			toast("Nothing here. Go near a tree, rock, bush or the water.")
		return
	var kind: String = n.get_meta("kind")
	match kind:
		"tree":
			hit_resource(n, "wood", 2 if inv.has("axe") else 1)
		"rock":
			hit_resource(n, "stone", 1)
		"bush":
			pick_bush(n)
		"fire":
			cook()
		"shelter":
			sleep_in_shelter()
		"box":
			use_box()
		"npc":
			await talk_npc()


func hit_resource(n, item: String, gain: int) -> void:
	player.swing()
	play_sfx("chop")
	if not add_item(item, gain):
		return
	if item == "wood":
		counters["wood"] += gain
		ach("first_wood", "First Wood")
	elif item == "stone":
		counters["stone"] += gain
	var hp: int = int(n.get_meta("hp")) - 1
	n.set_meta("hp", hp)
	give_xp(1)
	if hp <= 0:
		if n.get_meta("kind") == "tree":
			var tmm: MultiMesh = n.get_meta("mm")
			tmm.set_instance_transform(int(n.get_meta("idx")), Transform3D(Basis().scaled(Vector3.ZERO), Vector3.ZERO))
		n.remove_from_group("interact")
		n.queue_free()
	check_missions()


func pick_bush(n) -> void:
	if not n.get_meta("ready"):
		toast("No berries left. They will grow back.")
		return
	if add_item("berries", 3):
		n.set_meta("ready", false)
		n.get_meta("berries").visible = false
		play_sfx("pick")
		toast("Picked 3 berries.")
		get_tree().create_timer(90.0).timeout.connect(regrow_bush.bind(n))


func regrow_bush(n) -> void:
	if is_instance_valid(n):
		n.set_meta("ready", true)
		n.get_meta("berries").visible = true


func cook() -> void:
	if inv.get("raw_meat", 0) > 0:
		inv["raw_meat"] -= 1
		if inv["raw_meat"] <= 0:
			inv.erase("raw_meat")
		inv["cooked_meat"] = inv.get("cooked_meat", 0) + 1
		play_sfx("pick")
		toast("You cooked some meat!")
	else:
		toast("The fire keeps you warm and scares wolves. Bring raw meat to cook.")


func sleep_in_shelter() -> void:
	if not is_night():
		toast("You can only sleep at night.")
		return
	if time_of_day > 0.5:
		day += 1
	time_of_day = 0.27
	stats["hunger"] = maxf(10.0, stats["hunger"] - 10.0)
	stats["thirst"] = maxf(10.0, stats["thirst"] - 10.0)
	stats["hp"] = minf(100.0, stats["hp"] + 30.0)
	save_game()
	toast("You slept until morning. Day %d." % day, 3.5)
	check_missions()


func use_box() -> void:
	var movable := 0
	for k in inv.keys():
		if k != "axe" and k != "spear":
			movable += inv[k]
	if movable > 0:
		for k in inv.keys():
			if k == "axe" or k == "spear":
				continue
			box_store[k] = box_store.get(k, 0) + inv[k]
			inv.erase(k)
		toast("Stored your items in the box.")
	elif not box_store.is_empty():
		for k in box_store.keys():
			var space := MAX_ITEMS - inv_count()
			var take := mini(int(box_store[k]), space)
			if take > 0:
				inv[k] = inv.get(k, 0) + take
				box_store[k] -= take
				if box_store[k] <= 0:
					box_store.erase(k)
		toast("Took items from the box.")
	else:
		toast("The box is empty.")


func talk_npc() -> void:
	if not achievements.has("met_hermit"):
		achievements["met_hermit"] = true
		add_item("berries", 3)
		give_xp(20)
		toast("Hermit: Welcome, traveler. Take these berries.", 4.0)
		return
	toast("Hermit: hmm...", 1.5)
	var txt = await ai_ask("npc", "Give the player one short helpful hint.", npc_hint())
	toast("Hermit: " + str(txt), 7.0)


func do_attack() -> void:
	if state != "play":
		return
	player.swing()
	var dmg := 1.5
	if inv.has("spear"):
		dmg = 4.0
	elif inv.has("axe"):
		dmg = 2.5
	var best = null
	var bd := 3.0
	var list: Array = get_tree().get_nodes_in_group("animal")
	for a in list:
		var d: float = player.global_position.distance_to(a.global_position)
		if d < bd:
			bd = d
			best = a
	if best != null:
		best.hurt(dmg)
		play_sfx("chop")


func on_animal_killed(a) -> void:
	var table := {"rabbit": 1, "deer": 3, "boar": 3, "wolf": 2, "fox": 1}
	var meat: int = int(table.get(a.kind, 1))
	add_item("raw_meat", meat)
	counters["kills"] += 1
	give_xp(10 + meat * 3)
	toast("You got %d raw meat." % meat)
	ach("hunter", "Hunter")
	check_missions()


# =================================================================== inventory / crafting
func item_name(k: String) -> String:
	if ITEMS.has(k):
		return ITEMS[k][0]
	return k


func item_desc(k: String) -> String:
	if ITEMS.has(k):
		return ITEMS[k][1]
	return ""


func inv_count() -> int:
	var c := 0
	for k in inv:
		c += int(inv[k])
	return c


func add_item(k: String, n: int = 1) -> bool:
	if inv_count() + n > MAX_ITEMS:
		toast("Backpack is full!")
		return false
	inv[k] = int(inv.get(k, 0)) + n
	return true


func has_items(cost: Dictionary) -> bool:
	for k in cost:
		if int(inv.get(k, 0)) < int(cost[k]):
			return false
	return true


func remove_items(cost: Dictionary) -> void:
	for k in cost:
		inv[k] = int(inv.get(k, 0)) - int(cost[k])
		if inv[k] <= 0:
			inv.erase(k)


func use_item(k: String) -> void:
	if not inv.has(k):
		return
	match k:
		"berries":
			stats["hunger"] = minf(100.0, stats["hunger"] + 8.0)
			stats["thirst"] = minf(100.0, stats["thirst"] + 4.0)
			consume(k)
		"raw_meat":
			stats["hunger"] = minf(100.0, stats["hunger"] + 12.0)
			stats["hp"] -= 8.0
			consume(k)
			toast("Raw meat made you feel sick.")
			if stats["hp"] <= 0.0:
				die()
		"cooked_meat":
			stats["hunger"] = minf(100.0, stats["hunger"] + 35.0)
			stats["hp"] = minf(100.0, stats["hp"] + 5.0)
			consume(k)
		_:
			toast("Tools work automatically.")
	push_hud()


func consume(k: String) -> void:
	inv[k] -= 1
	if inv[k] <= 0:
		inv.erase(k)
	counters["food"] += 1
	play_sfx("pick")
	check_missions()


func craft(id: String) -> void:
	var r: Dictionary = RECIPES[id]
	var cost: Dictionary = r["cost"]
	if not has_items(cost):
		toast("Not enough materials.")
		return
	if id == "axe" or id == "spear":
		if inv.has(id):
			toast("You already have it.")
			return
		remove_items(cost)
		add_item(id, 1)
		toast("Crafted %s!" % r["name"])
		ach("crafter", "Crafter")
	else:
		var ok := place_structure(id)
		if not ok:
			return
		remove_items(cost)
		if id == "campfire":
			counters["fire"] += 1
			ach("fire", "Fire Starter")
		elif id == "shelter":
			counters["shelter"] += 1
		toast("%s placed!" % r["name"])
		close_panel()
	give_xp(10)
	check_missions()


# =================================================================== progression
func give_xp(n: int) -> void:
	xp += n
	var nl := 1 + int(floor(xp / 100.0))
	if nl > level:
		level = nl
		stats["hp"] = 100.0
		toast("LEVEL UP! You are level %d." % level, 3.5)


func ach(key: String, title: String) -> void:
	if achievements.has(key):
		return
	achievements[key] = true
	toast("Achievement: " + title, 3.0)
	give_xp(15)


func mission_progress() -> int:
	if mission_idx >= MISSIONS.size():
		return 0
	var k: String = MISSIONS[mission_idx]["k"]
	if k == "day":
		return day
	return int(counters.get(k, 0))


func check_missions() -> void:
	while mission_idx < MISSIONS.size():
		var m: Dictionary = MISSIONS[mission_idx]
		if mission_progress() >= int(m["n"]):
			give_xp(int(m["xp"]))
			toast("Mission complete! +%d XP" % int(m["xp"]), 4.0)
			mission_idx += 1
			if mission_idx >= MISSIONS.size():
				ach("survivor", "Island Survivor")
		else:
			break
	if not bonus.is_empty():
		var done: int = int(counters.get(bonus["k"], 0)) - int(bonus["base"])
		if done >= int(bonus["need"]):
			give_xp(int(bonus["xp"]))
			toast("Bonus mission complete! +%d XP" % int(bonus["xp"]), 4.0)
			bonus = {}
	hud.set_mission(mission_text())


func mission_text() -> String:
	var s := ""
	if mission_idx < MISSIONS.size():
		var m: Dictionary = MISSIONS[mission_idx]
		s = "MISSION: %s (%d/%d)" % [m["t"], mini(mission_progress(), int(m["n"])), int(m["n"])]
	else:
		s = "All missions complete! Explore freely."
	if not bonus.is_empty():
		var done: int = int(counters.get(bonus["k"], 0)) - int(bonus["base"])
		s += "\nBONUS: %s (%d/%d)" % [bonus["t"], clampi(done, 0, int(bonus["need"])), int(bonus["need"])]
	return s


func map_markers() -> Array:
	var out := []
	var fl: Array = get_tree().get_nodes_in_group("fires")
	for f in fl:
		if not f.is_queued_for_deletion():
			out.append({"pos": f.global_position, "col": Color(1.0, 0.6, 0.1), "shape": "circle"})
	var sl: Array = get_tree().get_nodes_in_group("shelters")
	for s in sl:
		if not s.is_queued_for_deletion():
			out.append({"pos": s.global_position, "col": Color(0.3, 0.6, 1.0), "shape": "square"})
	if counters["ruins"] > 0:
		out.append({"pos": ruins_pos, "col": Color(0.75, 0.45, 0.95), "shape": "diamond"})
	else:
		out.append({"pos": ruins_pos + Vector3(7, 0, -6), "col": Color(0.85, 0.6, 1.0), "shape": "unknown"})
	if achievements.has("met_hermit"):
		out.append({"pos": camp_pos, "col": Color(1.0, 0.9, 0.3), "shape": "square"})
	return out


# =================================================================== guide / AI (optional)
func guide_text(topic: String) -> String:
	return GUIDE.get(topic, GUIDE["Intro"])


func npc_hint() -> String:
	var pp: Vector3 = player.global_position
	if stats["hunger"] < 35.0:
		return "You look hungry. Red bushes have berries, and cooked meat fills you best."
	if stats["thirst"] < 35.0:
		return "Thirsty? Walk to the shore and tap INTERACT to drink."
	if is_night() and not is_safe(pp):
		return "Night is dangerous. Wolves fear fire. Build a campfire."
	if not inv.has("axe"):
		return "A stone axe doubles your wood. It costs 3 wood and 2 stone."
	if counters["shelter"] == 0:
		return "Build a shelter. Then you can sleep through the night."
	if counters["ruins"] == 0:
		return "Ancient stones stand on the high ground near the mountain."
	return "You are doing well. Keep exploring and stay alive until day 4."


func state_summary() -> Dictionary:
	return {"day": day, "hp": int(stats["hp"]), "hunger": int(stats["hunger"]), "thirst": int(stats["thirst"]), "inventory": inv, "mission": mission_text(), "night": is_night()}


func ai_ask(kind: String, question: String, fallback: String) -> String:
	if ai_endpoint == "" or not settings["ai"]:
		return fallback
	var http := HTTPRequest.new()
	http.timeout = 8.0
	add_child(http)
	var body := JSON.stringify({"kind": kind, "question": question, "state": state_summary()})
	var err := http.request(ai_endpoint, ["Content-Type: application/json"], HTTPClient.METHOD_POST, body)
	if err != OK:
		http.queue_free()
		return fallback
	var res = await http.request_completed
	http.queue_free()
	if res[0] != HTTPRequest.RESULT_SUCCESS or res[1] != 200:
		return fallback
	var parsed = JSON.parse_string(res[3].get_string_from_utf8())
	if typeof(parsed) == TYPE_DICTIONARY and parsed.has("text"):
		return str(parsed["text"])
	return fallback


func ask_guide() -> String:
	var r: String = await ai_ask("guide", "Give one short helpful survival tip for the current game state.", npc_hint())
	return r


func generate_bonus() -> String:
	if not bonus.is_empty():
		return "Finish your current bonus mission first."
	var kinds := ["wood", "stone", "food", "kills"]
	var names := {"wood": "Collect %d wood", "stone": "Collect %d stone", "food": "Eat food %d times", "kills": "Hunt %d animals"}
	var k: String = kinds[randi() % kinds.size()]
	var n: int = randi_range(3, 8)
	var title: String = names[k] % n
	var txt: String = await ai_ask("mission", "Create one new exploration or collection mission.", "")
	if txt != "":
		var parsed = JSON.parse_string(txt)
		if typeof(parsed) == TYPE_DICTIONARY and parsed.has("kind") and parsed.has("amount") and kinds.has(str(parsed["kind"])):
			k = str(parsed["kind"])
			n = clampi(int(parsed["amount"]), 1, 12)
			title = str(parsed.get("title", names[k] % n))
	bonus = {"t": title, "k": k, "base": int(counters[k]), "need": n, "xp": 25 + n * 5}
	hud.set_mission(mission_text())
	return "New bonus mission: " + title
