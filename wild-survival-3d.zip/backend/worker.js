// OPTIONAL AI backend (Cloudflare Worker, free plan). The API key stays here as a secret,
// never inside the Android game. Deploy, add secret ANTHROPIC_API_KEY, then put the
// worker URL into `ai_endpoint` at the top of main.gd.
export default {
  async fetch(request, env) {
    const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type" };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return new Response("POST only", { status: 405, headers: cors });
    let body;
    try { body = await request.json(); } catch (e) { return new Response("bad json", { status: 400, headers: cors }); }
    const rules = {
      guide: "You are a friendly survival guide inside a fictional island survival game. Answer in at most 3 short sentences.",
      npc: "You are an old hermit NPC in a fictional island survival game. Reply with at most 2 short sentences containing a useful hint.",
      mission: 'You create fictional game missions. Reply ONLY with JSON: {"title": string, "kind": "wood"|"stone"|"food"|"kills", "amount": integer 3-8}.'
    };
    const system = rules[String(body.kind)] || rules.guide;
    const user = "Game state: " + JSON.stringify(body.state || {}).slice(0, 800) + "\nRequest: " + String(body.question || "").slice(0, 300);
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 200, system: system, messages: [{ role: "user", content: user }] })
    });
    if (!r.ok) return new Response(JSON.stringify({ error: "upstream" }), { status: 502, headers: cors });
    const data = await r.json();
    const text = (data.content && data.content[0] && data.content[0].text) || "";
    return new Response(JSON.stringify({ text: text }), { headers: Object.assign({ "content-type": "application/json" }, cors) });
  }
};
