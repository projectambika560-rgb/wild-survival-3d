extends Node3D

var kind := "deer"
var main
var hp := 5.0
var speed := 3.0
var flee_range := 14.0
var home := Vector3.ZERO
var target := Vector3.ZERO
var wander_t := 0.0
var idle_t := 0.0
var atk_cd := 0.0
var provoked := false
var legs: Array = []
var wings: Array = []
var phase := 0.0
var moving := false
var fly_angle := 0.0
var fly_r := 10.0
var fly_h := 14.0
var body_col := Color(0.6, 0.4, 0.25)
var sc := 1.0


func box(parent: Node, size: Vector3, pos: Vector3, col: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	m.mesh = b
	var mt := StandardMaterial3D.new()
	mt.albedo_color = col
	mt.roughness = 1.0
	m.material_override = mt
	m.position = pos
	m.visibility_range_end = 110.0
	parent.add_child(m)
	return m


func setup(k: String, m, pos: Vector3) -> void:
	kind = k
	main = m
	position = pos
	home = pos
	match kind:
		"rabbit":
			hp = 2.0
			speed = 4.5
			flee_range = 9.0
			sc = 0.45
			body_col = Color(0.75, 0.7, 0.62)
		"deer":
			hp = 5.0
			speed = 6.0
			flee_range = 17.0
			sc = 1.0
			body_col = Color(0.62, 0.42, 0.22)
		"boar":
			hp = 8.0
			speed = 4.2
			sc = 0.8
			body_col = Color(0.3, 0.22, 0.18)
		"wolf":
			hp = 7.0
			speed = 5.5
			sc = 0.85
			body_col = Color(0.45, 0.45, 0.5)
		"fox":
			hp = 3.0
			speed = 5.0
			flee_range = 12.0
			sc = 0.6
			body_col = Color(0.85, 0.4, 0.12)
		"bird":
			sc = 0.4
			body_col = Color(0.2, 0.25, 0.6)
	if kind == "bird":
		build_bird()
		add_to_group("bird")
		fly_angle = randf() * TAU
		fly_r = randf_range(8.0, 18.0)
		fly_h = randf_range(10.0, 18.0)
		return
	add_to_group("animal")
	if not try_model():
		build_quad()
	pick_target()


func part(parent: Node, mesh: Mesh, pos: Vector3, col: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	var mt := StandardMaterial3D.new()
	mt.albedo_color = col
	mt.roughness = 0.9
	m.material_override = mt
	m.position = pos
	m.visibility_range_end = 110.0
	parent.add_child(m)
	return m


func capsule(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = maxf(h, r * 2.0 + 0.01)
	c.radial_segments = 8
	c.rings = 3
	return c


func sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 8
	s.rings = 4
	return s


func cylm(top: float, bottom: float, h: float) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = top
	c.bottom_radius = bottom
	c.height = h
	c.radial_segments = 6
	c.rings = 1
	return c


func try_model() -> bool:
	var list: Array = main.model_animals.get(kind, [])
	if list.is_empty():
		return false
	var res = list[randi() % list.size()]
	var node: Node3D = null
	if res is PackedScene:
		node = res.instantiate() as Node3D
	elif res is Mesh:
		var mi := MeshInstance3D.new()
		mi.mesh = res
		node = mi
	if node == null:
		return false
	var holder := Node3D.new()
	add_child(holder)
	holder.add_child(node)
	var bb := AABB()
	var first := true
	var meshes: Array = node.find_children("*", "MeshInstance3D", true, false)
	if node is MeshInstance3D:
		meshes.append(node)
	for mm in meshes:
		var t: Transform3D = holder.global_transform.affine_inverse() * mm.global_transform
		var ab: AABB = t * mm.get_aabb()
		if first:
			bb = ab
			first = false
		else:
			bb = bb.merge(ab)
	if first or bb.size.length() < 0.001:
		holder.queue_free()
		return false
	var target := 1.0
	match kind:
		"rabbit":
			target = 0.5
		"fox":
			target = 0.9
		"wolf":
			target = 1.3
		"boar":
			target = 1.3
		"deer":
			target = 1.8
	var longest := maxf(bb.size.x, bb.size.z)
	var s := target / maxf(longest, 0.01)
	holder.scale = Vector3(s, s, s)
	holder.position.y = -bb.position.y * s
	var ap = node.find_child("AnimationPlayer", true, false)
	if ap != null:
		var anims: PackedStringArray = ap.get_animation_list()
		var pick := ""
		for an in anims:
			var lo := String(an).to_lower()
			if "walk" in lo or "gallop" in lo or "run" in lo:
				pick = an
				break
		if pick == "" and anims.size() > 0:
			pick = anims[0]
		if pick != "":
			ap.get_animation(pick).loop_mode = Animation.LOOP_LINEAR
			ap.play(pick)
	return true


func build_quad() -> void:
	var lh := 0.55 * sc
	if kind == "deer":
		lh = 0.85
	var by := lh + 0.25 * sc
	var body := part(self, capsule(0.26 * sc, 1.2 * sc), Vector3(0, by, 0), body_col)
	body.rotation_degrees.x = 90.0
	var head := part(self, sphere(0.17 * sc), Vector3(0, by + 0.22 * sc, 0.68 * sc), body_col.lightened(0.1))
	head.scale = Vector3(1.0, 1.0, 1.35)
	part(self, sphere(0.09 * sc), Vector3(0, by + 0.17 * sc, 0.88 * sc), body_col.darkened(0.35))
	for s in [1.0, -1.0]:
		var ear := part(self, cylm(0.0, 0.05 * sc, 0.2 * sc), Vector3(0.09 * sc * s, by + 0.42 * sc, 0.62 * sc), body_col.darkened(0.1))
		if kind == "rabbit":
			ear.scale = Vector3(1.0, 2.5, 1.0)
	if kind == "deer":
		box(self, Vector3(0.05, 0.35, 0.05), Vector3(0.1, by + 0.6, 0.7), Color(0.8, 0.75, 0.6))
		box(self, Vector3(0.05, 0.35, 0.05), Vector3(-0.1, by + 0.6, 0.7), Color(0.8, 0.75, 0.6))
	if kind == "wolf" or kind == "fox":
		var tail := part(self, cylm(0.0, 0.08 * sc, 0.6 * sc), Vector3(0, by + 0.1, -0.85 * sc), body_col.darkened(0.15))
		tail.rotation_degrees.x = -72.0
	if kind == "rabbit":
		part(self, sphere(0.07), Vector3(0, by + 0.05, -0.3), Color(1, 1, 1))
	for i in 4:
		var pv := Node3D.new()
		var sx := 1.0 if i % 2 == 0 else -1.0
		var sz := 1.0 if i < 2 else -1.0
		pv.position = Vector3(0.17 * sc * sx, lh, 0.4 * sc * sz)
		add_child(pv)
		part(pv, cylm(0.06 * sc, 0.045 * sc, lh), Vector3(0, -lh * 0.5, 0), body_col.darkened(0.25))
		legs.append(pv)


func build_bird() -> void:
	box(self, Vector3(0.25, 0.2, 0.5), Vector3.ZERO, body_col)
	box(self, Vector3(0.14, 0.14, 0.16), Vector3(0, 0.08, 0.3), body_col.lightened(0.2))
	for s in [1.0, -1.0]:
		var pv := Node3D.new()
		pv.position = Vector3(0.12 * s, 0.05, 0)
		add_child(pv)
		box(pv, Vector3(0.6, 0.03, 0.3), Vector3(0.3 * s, 0, 0), body_col.darkened(0.1))
		wings.append(pv)


func pick_target() -> void:
	var a := randf() * TAU
	var r := randf_range(3.0, 12.0)
	target = home + Vector3(cos(a) * r, 0.0, sin(a) * r)
	wander_t = randf_range(3.0, 7.0)


func wander(delta: float) -> Vector3:
	wander_t -= delta
	var d := target - global_position
	d.y = 0.0
	if wander_t <= 0.0 or d.length() < 1.0:
		pick_target()
		if randf() < 0.4:
			idle_t = randf_range(1.5, 4.0)
	if idle_t > 0.0:
		idle_t -= delta
		return Vector3.ZERO
	return d.normalized() * speed * 0.35


func fly(delta: float) -> void:
	fly_angle += delta * 0.5
	phase += delta * 12.0
	var x := home.x + cos(fly_angle) * fly_r
	var z := home.z + sin(fly_angle) * fly_r
	var h: float = main.height_at(x, z)
	global_position = Vector3(x, maxf(h, 0.0) + fly_h + sin(fly_angle * 3.0), z)
	rotation.y = atan2(-sin(fly_angle), cos(fly_angle))
	if wings.size() == 2:
		wings[0].rotation.z = sin(phase) * 0.7
		wings[1].rotation.z = -sin(phase) * 0.7


func _process(delta: float) -> void:
	if main == null or main.state != "play":
		return
	if kind == "bird":
		fly(delta)
		return
	scale = scale.lerp(Vector3.ONE, minf(1.0, 10.0 * delta))
	var pp: Vector3 = main.player.global_position
	var to_p := pp - global_position
	to_p.y = 0.0
	var dist := to_p.length()
	atk_cd = maxf(0.0, atk_cd - delta)
	var safe: bool = main.player_safe
	var vel := Vector3.ZERO
	var fleeing := false
	match kind:
		"rabbit", "deer", "fox":
			if dist < flee_range:
				vel = -to_p.normalized() * speed
				fleeing = true
			else:
				vel = wander(delta)
		"wolf":
			if dist < 24.0 and not safe:
				vel = to_p.normalized() * speed
				if dist < 1.9:
					vel = Vector3.ZERO
					if atk_cd <= 0.0:
						atk_cd = 1.3
						main.damage_player(9.0)
			elif safe and dist < 10.0:
				vel = -to_p.normalized() * speed * 0.6
				fleeing = true
			else:
				vel = wander(delta)
		"boar":
			if provoked and dist < 30.0 and not safe:
				vel = to_p.normalized() * speed
				if dist < 1.8:
					vel = Vector3.ZERO
					if atk_cd <= 0.0:
						atk_cd = 1.5
						main.damage_player(12.0)
			else:
				vel = wander(delta)
	moving = vel.length() > 0.1
	if moving:
		var np := global_position + vel * delta
		var h: float = main.height_at(np.x, np.z)
		if h < 0.6 or h > 15.0:
			vel = Vector3.ZERO
			moving = false
			if not fleeing:
				pick_target()
		else:
			global_position = Vector3(np.x, h, np.z)
			rotation.y = lerp_angle(rotation.y, atan2(vel.x, vel.z), minf(1.0, 8.0 * delta))
	else:
		var gh: float = main.height_at(global_position.x, global_position.z)
		global_position.y = gh
	if moving:
		phase += delta * vel.length() * 3.0
		for i in legs.size():
			legs[i].rotation.x = sin(phase + (PI if i % 2 == 1 else 0.0)) * 0.6
	else:
		for i in legs.size():
			legs[i].rotation.x = lerpf(legs[i].rotation.x, 0.0, 8.0 * delta)


func hurt(dmg: float) -> void:
	hp -= dmg
	provoked = true
	scale = Vector3.ONE * 1.18
	if hp <= 0.0:
		main.on_animal_killed(self)
		queue_free()
