# Wild Survival 3D (Godot 4.2, Android)

## Phone se GitHub par kaise chalayein
1. Repo kholo > Add file > Create new file. Naam: .github/workflows/build.yml  (isme build.yml ka text paste karo)
2. Add file > Upload files > wild-survival-3d.zip upload karo > Commit.
   (Workflow khud zip extract karke APK banata hai.)
3. Repo > Actions > "Build Android APK" khulne do (5-10 minute).
4. Green hone par run kholo > neeche Artifacts > WildSurvival3D-debug-apk download karo.
5. APK ko phone me kholo > "Install unknown apps" allow karo > Install.
Agar red (fail) ho: Artifacts me "build-log" download karke mujhe bhejo.

## Controls
Left: joystick. Right: camera drag. INTERACT = chop/mine/pick/drink/cook/sleep/talk. HIT = attack. BAG, MAKE (crafting), ? (guide), minimap tap = map.
PC test: WASD, Space, E, F, Shift, arrows, I, C.
