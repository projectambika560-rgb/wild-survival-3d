extends CanvasLayer

var main
var vs := Vector2(1280, 720)
var modal := ""
var joy_id := -1
var joy_center := Vector2.ZERO
var look_id := -1
var root: Control
var gameplay: Control
var panels := {}
var btn_geo := {}
var btn_nodes := {}
var btn_lbls := {}
var bars := {}
var joy_base: TextureRect
var joy_knob: TextureRect
var circ_cache := {}
var mission_lbl: Label
var toast_lbl: Label
var toast_time := 0.0
var clock_lbl: Label
var minimap: Control
var minimap_img: TextureRect
var minimap_over: Control
var flash_rect: ColorRect
var loading_lbl: Label
var inv_grid: GridContainer
var inv_info: Label
var inv_cap: Label
var inv_sel := ""
var craft_list: VBoxContainer
var guide_text: Label
var map_img: TextureRect
var map_over: Control
var quality_btns: Array = []
var vol_slider: HSlider
var ai_btn: Button
var continue_btn: Button
var redraw_t := 0.0
var gold := Color(0.98, 0.82, 0.4)


# ------------------------------------------------------------ helpers
func style(col: Color, rad: int = 12, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(rad)
	s.border_color = border
	s.set_border_width_all(bw)
	return s


func lbl(text: String, size: int = 22, col: Color = Color(0.95, 0.93, 0.85), center: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 4)
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func make_button(text: String, size: Vector2, cb: Callable, col: Color = Color(0.2, 0.4, 0.22)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 26)
	b.add_theme_stylebox_override("normal", style(col, 14, Color(0.9, 0.8, 0.5, 0.8), 2))
	b.add_theme_stylebox_override("hover", style(col.lightened(0.12), 14, Color(1, 0.9, 0.6), 2))
	b.add_theme_stylebox_override("pressed", style(col.darkened(0.2), 14, Color(1, 0.9, 0.6), 2))
	b.add_theme_stylebox_override("disabled", style(Color(0.2, 0.2, 0.2, 0.7), 14, Color(0.5, 0.5, 0.5, 0.5), 2))
	b.pressed.connect(cb)
	return b


func make_panel(pname: String, alpha: float) -> Control:
	var p := Control.new()
	p.set_anchors_preset(Control.PRESET_FULL_RECT)
	p.mouse_filter = Control.MOUSE_FILTER_STOP
	p.visible = false
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.05, 0.03, alpha)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(bg)
	root.add_child(p)
	panels[pname] = p
	return p


func card(p: Control, minsize: Vector2) -> VBoxContainer:
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	p.add_child(cc)
	var pc := PanelContainer.new()
	var sb := style(Color(0.07, 0.12, 0.08, 0.95), 20, Color(0.85, 0.7, 0.35), 3)
	sb.content_margin_left = 28.0
	sb.content_margin_right = 28.0
	sb.content_margin_top = 22.0
	sb.content_margin_bottom = 22.0
	pc.add_theme_stylebox_override("panel", sb)
	pc.custom_minimum_size = minsize
	cc.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	pc.add_child(vb)
	return vb


func center_add(parent: Control, c: Control) -> void:
	c.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	parent.add_child(c)


# ------------------------------------------------------------ setup
func setup(m) -> void:
	main = m
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	build_gameplay()
	flash_rect = ColorRect.new()
	flash_rect.color = Color(0.8, 0, 0, 0)
	flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(flash_rect)
	build_menu()
	build_pause()
	build_settings()
	build_inventory()
	build_craft()
	build_map()
	build_guide()
	build_dead()
	build_loading()
	get_viewport().size_changed.connect(layout)
	layout()


func circle_tex(fill: Color, border: Color, bw: float) -> ImageTexture:
	var key := fill.to_html() + border.to_html() + str(bw)
	if circ_cache.has(key):
		return circ_cache[key]
	var sz := 96
	var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var c := sz * 0.5
	var r := c - 1.0
	for x in sz:
		for y in sz:
			var d := Vector2(x + 0.5 - c, y + 0.5 - c).length()
			var a := clampf(r - d + 0.5, 0.0, 1.0)
			var col := fill
			if d > r - bw:
				col = border
			img.set_pixel(x, y, Color(col.r, col.g, col.b, col.a * a))
	var t := ImageTexture.create_from_image(img)
	circ_cache[key] = t
	return t


func make_round(bname: String, text: String, r: float, col: Color) -> void:
	var p := TextureRect.new()
	p.texture = circle_tex(Color(col.r, col.g, col.b, 0.55), Color(1, 0.95, 0.7, 0.85), 3.0)
	p.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	p.stretch_mode = TextureRect.STRETCH_SCALE
	p.size = Vector2(r * 2.0, r * 2.0)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := lbl(text, 22 if r > 45.0 else 17, Color(1, 1, 1), true)
	l.set_anchors_preset(Control.PRESET_FULL_RECT)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	p.add_child(l)
	gameplay.add_child(p)
	btn_nodes[bname] = p
	btn_lbls[bname] = l
	btn_geo[bname] = [Vector2.ZERO, r]


func build_gameplay() -> void:
	gameplay = Control.new()
	gameplay.set_anchors_preset(Control.PRESET_FULL_RECT)
	gameplay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gameplay.visible = false
	root.add_child(gameplay)
	var defs := [["HP", Color(0.85, 0.2, 0.2)], ["STAMINA", Color(0.3, 0.8, 0.3)], ["FOOD", Color(0.95, 0.6, 0.15)], ["WATER", Color(0.25, 0.6, 0.95)]]
	for i in defs.size():
		var pb := ProgressBar.new()
		pb.show_percentage = false
		pb.min_value = 0.0
		pb.max_value = 100.0
		pb.value = 100.0
		pb.position = Vector2(100, 14 + i * 30)
		pb.custom_minimum_size = Vector2(230, 20)
		pb.size = Vector2(230, 20)
		pb.add_theme_stylebox_override("background", style(Color(0, 0, 0, 0.5), 6))
		pb.add_theme_stylebox_override("fill", style(defs[i][1], 6))
		pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		gameplay.add_child(pb)
		var l := lbl(defs[i][0], 16)
		l.position = Vector2(14, 12 + i * 30)
		gameplay.add_child(l)
		bars[defs[i][0]] = pb
	clock_lbl = lbl("", 20, gold)
	gameplay.add_child(clock_lbl)
	mission_lbl = lbl("", 20)
	mission_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mission_lbl.custom_minimum_size = Vector2(340, 0)
	mission_lbl.position = Vector2(14, 140)
	mission_lbl.size = Vector2(340, 80)
	gameplay.add_child(mission_lbl)
	toast_lbl = lbl("", 26, Color(1, 1, 1), true)
	toast_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_lbl.size = Vector2(640, 80)
	toast_lbl.modulate.a = 0.0
	gameplay.add_child(toast_lbl)
	joy_base = TextureRect.new()
	joy_base.texture = circle_tex(Color(1, 1, 1, 0.12), Color(1, 1, 1, 0.4), 3.0)
	joy_base.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	joy_base.stretch_mode = TextureRect.STRETCH_SCALE
	joy_base.size = Vector2(170, 170)
	joy_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gameplay.add_child(joy_base)
	joy_knob = TextureRect.new()
	joy_knob.texture = circle_tex(Color(1, 1, 1, 0.35), Color(1, 1, 1, 0.6), 3.0)
	joy_knob.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	joy_knob.stretch_mode = TextureRect.STRETCH_SCALE
	joy_knob.size = Vector2(70, 70)
	joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gameplay.add_child(joy_knob)
	make_round("interact", "Interact", 68.0, Color(0.2, 0.6, 0.25))
	make_round("jump", "JUMP", 50.0, Color(0.2, 0.4, 0.7))
	make_round("attack", "HIT", 50.0, Color(0.75, 0.25, 0.2))
	make_round("run", "RUN", 40.0, Color(0.5, 0.5, 0.5))
	make_round("pause", "II", 28.0, Color(0.3, 0.3, 0.3))
	make_round("bag", "BAG", 34.0, Color(0.55, 0.38, 0.15))
	make_round("craft", "MAKE", 34.0, Color(0.55, 0.38, 0.15))
	make_round("guide", "?", 28.0, Color(0.3, 0.3, 0.6))
	minimap = Control.new()
	minimap.size = Vector2(170, 170)
	minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gameplay.add_child(minimap)
	var mbg := Panel.new()
	mbg.set_anchors_preset(Control.PRESET_FULL_RECT)
	mbg.add_theme_stylebox_override("panel", style(Color(0, 0, 0, 0.5), 10, Color(0.9, 0.8, 0.5, 0.9), 2))
	mbg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	minimap.add_child(mbg)
	minimap_img = TextureRect.new()
	minimap_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	minimap_img.stretch_mode = TextureRect.STRETCH_SCALE
	minimap_img.set_anchors_preset(Control.PRESET_FULL_RECT)
	minimap_img.offset_left = 5.0
	minimap_img.offset_top = 5.0
	minimap_img.offset_right = -5.0
	minimap_img.offset_bottom = -5.0
	minimap_img.mouse_filter = Control.MOUSE_FILTER_IGNORE
	minimap.add_child(minimap_img)
	minimap_over = Control.new()
	minimap_over.set_anchors_preset(Control.PRESET_FULL_RECT)
	minimap_over.offset_left = 5.0
	minimap_over.offset_top = 5.0
	minimap_over.offset_right = -5.0
	minimap_over.offset_bottom = -5.0
	minimap_over.mouse_filter = Control.MOUSE_FILTER_IGNORE
	minimap_over.draw.connect(func(): draw_markers(minimap_over, 4.0))
	minimap.add_child(minimap_over)


func build_loading() -> void:
	var p := make_panel("loading", 1.0)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	p.add_child(cc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 20)
	cc.add_child(vb)
	vb.add_child(lbl("WILD SURVIVAL 3D", 60, gold, true))
	loading_lbl = lbl("Loading...", 28, Color(0.9, 0.95, 0.9), true)
	vb.add_child(loading_lbl)


func build_menu() -> void:
	var p := make_panel("menu", 0.28)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	p.add_child(cc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	cc.add_child(vb)
	var t := lbl("WILD SURVIVAL 3D", 76, gold, true)
	t.add_theme_constant_override("outline_size", 12)
	vb.add_child(t)
	vb.add_child(lbl("Survive  -  Build  -  Explore", 26, Color(0.9, 0.95, 0.85), true))
	var sp := Control.new()
	sp.custom_minimum_size = Vector2(0, 24)
	vb.add_child(sp)
	center_add(vb, make_button("NEW GAME", Vector2(380, 66), func(): main.start_game(false), Color(0.2, 0.45, 0.22)))
	continue_btn = make_button("CONTINUE", Vector2(380, 66), func(): main.start_game(true), Color(0.2, 0.35, 0.5))
	center_add(vb, continue_btn)
	center_add(vb, make_button("SETTINGS", Vector2(380, 66), func(): main.open_panel("settings"), Color(0.4, 0.33, 0.15)))
	center_add(vb, make_button("EXIT", Vector2(380, 66), func(): get_tree().quit(), Color(0.5, 0.2, 0.18)))


func build_pause() -> void:
	var p := make_panel("pause", 0.6)
	var vb := card(p, Vector2(520, 380))
	vb.add_child(lbl("PAUSED", 42, gold, true))
	center_add(vb, make_button("RESUME", Vector2(360, 62), func(): main.close_panel(), Color(0.2, 0.45, 0.22)))
	center_add(vb, make_button("SETTINGS", Vector2(360, 62), func(): main.open_panel("settings"), Color(0.4, 0.33, 0.15)))
	center_add(vb, make_button("SAVE GAME", Vector2(360, 62), func(): main.manual_save(), Color(0.2, 0.35, 0.5)))
	center_add(vb, make_button("SAVE + MAIN MENU", Vector2(360, 62), func(): main.go_to_menu(), Color(0.5, 0.2, 0.18)))


func build_dead() -> void:
	var p := make_panel("dead", 0.75)
	var vb := card(p, Vector2(520, 260))
	vb.add_child(lbl("YOU DIED", 48, Color(0.9, 0.3, 0.25), true))
	vb.add_child(lbl("The island is harsh. Try again!", 24, Color(0.9, 0.9, 0.9), true))
	center_add(vb, make_button("RESPAWN", Vector2(360, 62), func(): main.respawn(), Color(0.2, 0.45, 0.22)))


func build_settings() -> void:
	var p := make_panel("settings", 0.75)
	var vb := card(p, Vector2(640, 460))
	vb.add_child(lbl("SETTINGS", 38, gold))
	vb.add_child(lbl("Graphics quality", 24))
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	vb.add_child(hb)
	var names := ["LOW", "MEDIUM", "HIGH"]
	for i in 3:
		var b := make_button(names[i], Vector2(180, 56), Callable(main, "set_quality").bind(i))
		hb.add_child(b)
		quality_btns.append(b)
	vb.add_child(lbl("Volume", 24))
	vol_slider = HSlider.new()
	vol_slider.min_value = 0.0
	vol_slider.max_value = 1.0
	vol_slider.step = 0.05
	vol_slider.custom_minimum_size = Vector2(500, 36)
	vol_slider.value_changed.connect(Callable(main, "set_volume"))
	vb.add_child(vol_slider)
	ai_btn = make_button("AI FEATURES: OFF", Vector2(500, 56), func(): main.toggle_ai(), Color(0.3, 0.3, 0.55))
	vb.add_child(ai_btn)
	center_add(vb, make_button("BACK", Vector2(260, 58), func(): main.settings_back(), Color(0.4, 0.33, 0.15)))


func build_inventory() -> void:
	var p := make_panel("inventory", 0.6)
	var vb := card(p, Vector2(820, 480))
	vb.add_child(lbl("BACKPACK", 36, gold))
	inv_cap = lbl("", 20)
	vb.add_child(inv_cap)
	inv_grid = GridContainer.new()
	inv_grid.columns = 5
	inv_grid.add_theme_constant_override("h_separation", 10)
	inv_grid.add_theme_constant_override("v_separation", 10)
	vb.add_child(inv_grid)
	inv_info = lbl("Tap an item to see what it does.", 20)
	inv_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inv_info.custom_minimum_size = Vector2(760, 60)
	vb.add_child(inv_info)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	hb.add_child(make_button("USE / EAT", Vector2(200, 56), use_selected, Color(0.2, 0.45, 0.22)))
	hb.add_child(make_button("CRAFTING", Vector2(200, 56), func(): main.open_panel("craft"), Color(0.4, 0.33, 0.15)))
	hb.add_child(make_button("CLOSE", Vector2(200, 56), func(): main.close_panel(), Color(0.5, 0.2, 0.18)))
	vb.add_child(hb)


func build_craft() -> void:
	var p := make_panel("craft", 0.6)
	var vb := card(p, Vector2(900, 480))
	vb.add_child(lbl("CRAFTING", 36, gold))
	craft_list = VBoxContainer.new()
	craft_list.add_theme_constant_override("separation", 10)
	vb.add_child(craft_list)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	hb.add_child(make_button("BACKPACK", Vector2(200, 56), func(): main.open_panel("inventory"), Color(0.4, 0.33, 0.15)))
	hb.add_child(make_button("CLOSE", Vector2(200, 56), func(): main.close_panel(), Color(0.5, 0.2, 0.18)))
	vb.add_child(hb)


func build_map() -> void:
	var p := make_panel("map", 0.7)
	var vb := card(p, Vector2(600, 640))
	vb.add_child(lbl("ISLAND MAP", 36, gold))
	map_img = TextureRect.new()
	map_img.custom_minimum_size = Vector2(500, 500)
	map_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	map_img.stretch_mode = TextureRect.STRETCH_SCALE
	vb.add_child(map_img)
	map_over = Control.new()
	map_over.set_anchors_preset(Control.PRESET_FULL_RECT)
	map_over.mouse_filter = Control.MOUSE_FILTER_IGNORE
	map_over.draw.connect(func(): draw_markers(map_over, 9.0))
	map_img.add_child(map_over)
	vb.add_child(lbl("Arrow = you   Orange = fire   Blue = shelter   ? = ruins area", 18))
	center_add(vb, make_button("CLOSE", Vector2(260, 56), func(): main.close_panel(), Color(0.5, 0.2, 0.18)))


func build_guide() -> void:
	var p := make_panel("guide", 0.65)
	var vb := card(p, Vector2(860, 500))
	vb.add_child(lbl("SURVIVAL GUIDE", 36, gold))
	guide_text = lbl("", 22)
	guide_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	guide_text.custom_minimum_size = Vector2(800, 190)
	vb.add_child(guide_text)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	for t in ["Crafting", "Resources", "Missions", "Survival"]:
		hb.add_child(make_button(t, Vector2(190, 52), Callable(self, "guide_topic").bind(t), Color(0.3, 0.38, 0.25)))
	vb.add_child(hb)
	var hb2 := HBoxContainer.new()
	hb2.add_theme_constant_override("separation", 10)
	hb2.add_child(make_button("ASK GUIDE", Vector2(250, 52), ask_ai, Color(0.3, 0.3, 0.55)))
	hb2.add_child(make_button("NEW BONUS MISSION", Vector2(310, 52), new_bounty, Color(0.3, 0.3, 0.55)))
	hb2.add_child(make_button("CLOSE", Vector2(200, 52), func(): main.close_panel(), Color(0.5, 0.2, 0.18)))
	vb.add_child(hb2)


# ------------------------------------------------------------ layout / input
func set_btn(n: String, c: Vector2) -> void:
	var r: float = btn_geo[n][1]
	btn_geo[n][0] = c
	btn_nodes[n].position = c - Vector2(r, r)


func place_joy(c: Vector2) -> void:
	joy_base.position = c - Vector2(85, 85)
	joy_knob.position = c - Vector2(35, 35)


func layout() -> void:
	vs = get_viewport().get_visible_rect().size
	set_btn("interact", Vector2(vs.x - 150.0, vs.y - 150.0))
	set_btn("jump", Vector2(vs.x - 290.0, vs.y - 95.0))
	set_btn("attack", Vector2(vs.x - 95.0, vs.y - 310.0))
	set_btn("run", Vector2(vs.x - 300.0, vs.y - 215.0))
	set_btn("pause", Vector2(vs.x - 40.0, 40.0))
	set_btn("bag", Vector2(vs.x - 110.0, 40.0))
	set_btn("craft", Vector2(vs.x - 180.0, 40.0))
	set_btn("guide", Vector2(vs.x - 248.0, 40.0))
	minimap.position = Vector2(vs.x - 190.0, 90.0)
	clock_lbl.position = Vector2(vs.x * 0.5 - 200.0, 10.0)
	clock_lbl.size = Vector2(400, 30)
	clock_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_lbl.position = Vector2(vs.x * 0.5 - 320.0, 70.0)
	if joy_id == -1:
		place_joy(Vector2(190.0, vs.y - 170.0))


func hit_button(p: Vector2) -> String:
	for n in btn_geo:
		var g: Array = btn_geo[n]
		if p.distance_to(g[0]) <= float(g[1]) * 1.15:
			return n
	if Rect2(minimap.position, minimap.size).has_point(p):
		return "map"
	return ""


func press_button(n: String) -> void:
	match n:
		"jump":
			main.player.want_jump = true
		"run":
			main.player.run_on = not main.player.run_on
			update_run()
		"interact":
			main.do_interact()
		"attack":
			main.do_attack()
		"pause":
			main.open_panel("pause")
		"bag":
			main.open_panel("inventory")
		"craft":
			main.open_panel("craft")
		"guide":
			main.open_panel("guide")
		"map":
			main.open_panel("map")


func update_run() -> void:
	if main.player == null:
		return
	var on: bool = main.player.run_on
	btn_nodes["run"].modulate = Color(0.5, 1.0, 0.5) if on else Color(1, 1, 1)
	btn_lbls["run"].text = "RUN\nON" if on else "RUN"


func _input(event) -> void:
	if main == null or main.state != "play" or modal != "":
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			var p: Vector2 = event.position
			var hit := hit_button(p)
			if hit != "":
				press_button(hit)
				return
			if p.x < vs.x * 0.45:
				if joy_id == -1:
					joy_id = event.index
					joy_center = p
					place_joy(p)
			elif look_id == -1:
				look_id = event.index
		else:
			if event.index == joy_id:
				joy_id = -1
				main.player.move_input = Vector2.ZERO
				place_joy(Vector2(190.0, vs.y - 170.0))
			elif event.index == look_id:
				look_id = -1
	elif event is InputEventScreenDrag:
		if event.index == joy_id:
			var v: Vector2 = event.position - joy_center
			var rad := 80.0
			var mag := minf(v.length(), rad)
			var nv := Vector2.ZERO
			if v.length() > 0.01:
				nv = v.normalized() * mag
			main.player.move_input = nv / rad
			joy_knob.position = joy_center + nv - Vector2(35, 35)
		elif event.index == look_id:
			main.player.look(event.relative)


# ------------------------------------------------------------ state
func show_panel(n: String) -> void:
	modal = n
	for k in panels:
		panels[k].visible = (k == n)
	gameplay.visible = (n == "")
	joy_id = -1
	look_id = -1
	if main.player != null:
		main.player.move_input = Vector2.ZERO
	place_joy(Vector2(190.0, vs.y - 170.0))
	match n:
		"inventory":
			refresh_inventory()
		"craft":
			refresh_craft()
		"map":
			map_over.queue_redraw()
		"guide":
			guide_text.text = main.guide_text("Intro")
		"settings":
			refresh_settings()
		"menu":
			continue_btn.disabled = not main.has_save()
		"":
			update_run()


func set_loading(t: String) -> void:
	loading_lbl.text = t


func set_map_texture(tex: Texture2D) -> void:
	map_img.texture = tex
	minimap_img.texture = tex


func update_stats(st: Dictionary, xp: int, lv: int, day: int, tod: float, raining: bool) -> void:
	bars["HP"].value = st["hp"]
	bars["STAMINA"].value = st["stamina"]
	bars["FOOD"].value = st["hunger"]
	bars["WATER"].value = st["thirst"]
	var hrs := int(tod * 24.0)
	var mins := int(fmod(tod * 24.0, 1.0) * 60.0)
	var wx := "  RAIN" if raining else ""
	clock_lbl.text = "Day %d   %02d:%02d%s   Lv %d  XP %d" % [day, hrs, mins, wx, lv, xp % 100]


func set_mission(t: String) -> void:
	mission_lbl.text = t


func set_hint(t: String) -> void:
	btn_lbls["interact"].text = t


func toast(t: String, secs: float = 2.5) -> void:
	toast_lbl.text = t
	toast_lbl.modulate.a = 1.0
	toast_time = secs


func flash() -> void:
	flash_rect.color = Color(0.8, 0, 0, 0.35)
	var tw := create_tween()
	tw.tween_property(flash_rect, "color:a", 0.0, 0.4)


func _process(delta: float) -> void:
	if toast_time > 0.0:
		toast_time -= delta
		if toast_time < 0.5:
			toast_lbl.modulate.a = maxf(toast_time, 0.0) / 0.5
	redraw_t += delta
	if redraw_t > 0.25:
		redraw_t = 0.0
		if gameplay.visible:
			minimap_over.queue_redraw()


# ------------------------------------------------------------ panels content
func refresh_settings() -> void:
	var names := ["LOW", "MEDIUM", "HIGH"]
	var q: int = int(main.settings["quality"])
	for i in 3:
		quality_btns[i].text = ("> " + names[i] + " <") if i == q else names[i]
	vol_slider.set_value_no_signal(float(main.settings["volume"]))
	if main.ai_endpoint == "":
		ai_btn.text = "AI: offline mode (no server set)"
		ai_btn.disabled = true
	else:
		ai_btn.disabled = false
		ai_btn.text = "AI FEATURES: ON" if main.settings["ai"] else "AI FEATURES: OFF"


func refresh_inventory() -> void:
	for c in inv_grid.get_children():
		c.queue_free()
	var keys: Array = main.inv.keys()
	keys.sort()
	var slots := maxi(10, keys.size())
	for i in slots:
		if i < keys.size():
			var k: String = keys[i]
			var b := make_button("%s\nx%d" % [main.item_name(k), main.inv[k]], Vector2(140, 84), select_item.bind(k), Color(0.25, 0.32, 0.2))
			b.add_theme_font_size_override("font_size", 20)
			inv_grid.add_child(b)
		else:
			var e := make_button("-", Vector2(140, 84), func(): pass, Color(0.15, 0.18, 0.15))
			e.disabled = true
			inv_grid.add_child(e)
	inv_cap.text = "Backpack: %d / %d" % [main.inv_count(), main.MAX_ITEMS]


func select_item(k: String) -> void:
	inv_sel = k
	inv_info.text = main.item_name(k) + ": " + main.item_desc(k)


func use_selected() -> void:
	if inv_sel == "":
		inv_info.text = "Select an item first."
		return
	main.use_item(inv_sel)
	if not main.inv.has(inv_sel):
		inv_sel = ""
	refresh_inventory()


func refresh_craft() -> void:
	for c in craft_list.get_children():
		c.queue_free()
	for id in main.RECIPES:
		var r: Dictionary = main.RECIPES[id]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var info := lbl("%s\n%s" % [r["name"], r["desc"]], 20)
		info.custom_minimum_size = Vector2(320, 0)
		row.add_child(info)
		var cost_txt := ""
		for k in r["cost"]:
			cost_txt += "%s %d/%d   " % [main.item_name(k), main.inv.get(k, 0), r["cost"][k]]
		var ok: bool = main.has_items(r["cost"])
		var cl := lbl(cost_txt, 20, Color(0.7, 1.0, 0.7) if ok else Color(1.0, 0.65, 0.6))
		cl.custom_minimum_size = Vector2(330, 0)
		row.add_child(cl)
		var b := make_button("CRAFT", Vector2(150, 54), craft_pressed.bind(id), Color(0.2, 0.45, 0.22))
		b.disabled = not ok
		row.add_child(b)
		craft_list.add_child(row)


func craft_pressed(id: String) -> void:
	main.craft(id)
	if modal == "craft":
		refresh_craft()


func guide_topic(t: String) -> void:
	guide_text.text = main.guide_text(t)


func ask_ai() -> void:
	guide_text.text = "Thinking..."
	var txt = await main.ask_guide()
	guide_text.text = str(txt)


func new_bounty() -> void:
	guide_text.text = "Creating a mission..."
	var txt = await main.generate_bonus()
	guide_text.text = str(txt)


func draw_markers(c: Control, dot: float) -> void:
	if main == null or main.player == null:
		return
	var half: float = main.world_size() * 0.5
	var sz := c.size
	var span := half * 2.0
	var big := dot > 6.0
	if big:
		for i in range(1, 4):
			var gxp := sz.x * i / 4.0
			var gyp := sz.y * i / 4.0
			c.draw_line(Vector2(gxp, 0), Vector2(gxp, sz.y), Color(1, 1, 1, 0.12), 1.0)
			c.draw_line(Vector2(0, gyp), Vector2(sz.x, gyp), Color(1, 1, 1, 0.12), 1.0)
		c.draw_rect(Rect2(Vector2.ZERO, sz), Color(0.95, 0.85, 0.5, 0.9), false, 3.0)
		c.draw_string(ThemeDB.fallback_font, Vector2(sz.x * 0.5 - 8.0, 28.0), "N", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 1, 1))
	for m in main.map_markers():
		var pos: Vector3 = m["pos"]
		var q := Vector2((pos.x + half) / span * sz.x, (pos.z + half) / span * sz.y)
		var col: Color = m["col"]
		var shape: String = m["shape"]
		match shape:
			"square":
				c.draw_rect(Rect2(q - Vector2(dot, dot), Vector2(dot, dot) * 2.0), col)
				c.draw_rect(Rect2(q - Vector2(dot, dot), Vector2(dot, dot) * 2.0), Color(0, 0, 0, 0.8), false, 2.0)
			"diamond":
				var pts := PackedVector2Array([q + Vector2(0, -dot * 1.3), q + Vector2(dot * 1.3, 0), q + Vector2(0, dot * 1.3), q + Vector2(-dot * 1.3, 0)])
				c.draw_colored_polygon(pts, col)
				c.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color(0, 0, 0, 0.8), 2.0)
			"unknown":
				c.draw_arc(q, dot * 1.6, 0.0, TAU, 20, col, 2.0)
				if big:
					c.draw_string(ThemeDB.fallback_font, q + Vector2(-6, 8), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, col)
			_:
				c.draw_circle(q, dot, col)
				c.draw_arc(q, dot, 0.0, TAU, 12, Color(0, 0, 0, 0.8), 2.0)
	var pp: Vector3 = main.player.global_position
	var f: Vector3 = main.player.face
	var pq := Vector2((pp.x + half) / span * sz.x, (pp.z + half) / span * sz.y)
	var f2 := Vector2(f.x, f.z)
	if f2.length() < 0.01:
		f2 = Vector2(0, -1)
	f2 = f2.normalized()
	var perp := Vector2(-f2.y, f2.x)
	var ar := dot * 1.1
	var tri := PackedVector2Array([pq + f2 * ar * 1.8, pq - f2 * ar + perp * ar, pq - f2 * ar - perp * ar])
	c.draw_colored_polygon(tri, Color(1, 1, 1))
	c.draw_polyline(PackedVector2Array([tri[0], tri[1], tri[2], tri[0]]), Color(0, 0, 0, 0.9), 2.0)
